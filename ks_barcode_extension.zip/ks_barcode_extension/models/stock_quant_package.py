# -*- coding: utf-8 -*-

from odoo import models, api
from odoo.osv import expression


class StockQuantPackage(models.Model):
    _inherit = 'stock.quant.package'

    @api.model
    def _name_search(self, name='', args=None, operator='ilike', limit=100, name_get_uid=None):
        """
        If the context has x_blp then scan the x_blp
        else call the super method to search full name and barcode
        """
        if self._context.get('x_blp'):
            args = args or []
            if operator == 'ilike' and not (name or '').strip():
                domain = []
            elif operator in expression.NEGATIVE_TERM_OPERATORS:
                domain = [('x_blp', operator, name)]
            else:
                domain = [('x_blp', operator, name)]
            return self._search(expression.AND([domain, args]), limit=limit, access_rights_uid=name_get_uid)
        else:
            return super(StockQuantPackage, self)._name_search(name, args, operator, limit, name_get_uid)

    def name_get(self):
        """
        This method can show the package name with package blp number.
        """
        return [(package.id, '%s - %s' % (package.name, package.x_blp)) for package in self]

    def ks_prepare_move_vals(self, picking_id):
        self.ensure_one()
        vals = {}
        for quant in self.quant_ids:
            vals.update({'move_vals': {'name': quant.product_id.display_name,
                                       'company_id': self.company_id.id,
                                       'product_id': quant.product_id.id,
                                       'product_uom_qty': quant.quantity,
                                       'product_uom': quant.product_uom_id.id,
                                       'location_id': quant.location_id.id,
                                       'location_dest_id': quant.location_id.id,
                                       'x_studio_future_lot': quant.x_future_lot,
                                       'picking_id': picking_id},
                        'quant_id': quant.id})
        return vals
