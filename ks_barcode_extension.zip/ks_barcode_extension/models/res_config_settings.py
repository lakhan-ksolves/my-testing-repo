# -*- coding: utf-8 -*-

from odoo import models, fields, api
from odoo.exceptions import ValidationError


class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    packages_limit = fields.Integer('Scanned line Limit', default=40,
                                    config_parameter='ks_barcode_extension.packages_limit')
    transfer_type = fields.Selection([('immediate', 'Immediate'),
                                      ('planned', 'Planned')], 'Transfer Type', default='immediate',
                                     config_parameter='ks_barcode_extension.transfer_type')
    internal_transfer_type = fields.Selection([('intra', 'Intra-Warehouse'),
                                               ('inter', 'Inter-Warehouse')], 'Internal Transfer Type', default='intra',
                                              config_parameter='ks_barcode_extension.internal_transfer_type')
    transfer_limit = fields.Integer('Transfer Limit', config_parameter='ks_barcode_extension.transfer_limit')
    physical_qty_limit = fields.Integer('Physical Quantity Limit', config_parameter='ks_barcode_extension.physical_available_limit')
    validate_cron_execution_time = fields.Integer('Validate Cron Time', default=10, config_parameter='ks_barcode_extension.validate_cron_execution_time')

    @api.constrains('validate_cron_execution_time')
    def _check_validate_time(self):
        for record in self:
            if record.validate_cron_execution_time > 10:
                raise ValidationError("The value of the validate transfer execution time cannot be more than 10.")