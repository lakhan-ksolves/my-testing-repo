# -*- coding: utf-8 -*-

from odoo import models, fields


class StockWarehouse(models.Model):
    _inherit = 'stock.warehouse'

    multi_location_pick = fields.Boolean('Multi-pick Location')
    suspense_location_id = fields.Many2one('stock.location', 'Suspense Location')
