# -*- coding: utf-8 -*-

import logging
import time

from odoo import models, fields, api, _
from odoo.exceptions import UserError
from odoo.osv import expression

_logger = logging.getLogger(__name__)


class InternalTransferScanner(models.Model):
    _name = 'internal.transfer.scanner'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = 'Internal Transfer Scanner'
    _order = 'id DESC'

    def _get_package_limit(self):
        """
        This method can return the packages limit set in the configuration.
        """
        return self.with_context(get_limit=True).check_package_limit()

    name = fields.Char('Name', default=_('New'), copy=False)
    location_id = fields.Many2one('stock.location', 'Source Location')
    location_dest_id = fields.Many2one('stock.location', 'Destination Location', inverse='add_destination_location')
    assigned_worker_id = fields.Many2one('res.users', string="Assigned User", copy=False)
    package_id = fields.Many2one('stock.quant.package', 'Add Box', inverse='add_package', copy=False)
    remove_package_id = fields.Many2one('stock.quant.package', 'Remove Box', inverse='remove_package', copy=False)
    state = fields.Selection([('draft', 'Draft'),
                              ('assigned', 'Assigned'),
                              ('moved', 'Moved'),
                              ('cancel', 'Cancel')], default='draft', string='Status', copy=False)
    internal_transfer_scanner_lines = fields.One2many('internal.transfer.scanner.line', 'internal_transfer_scanner_id',
                                                      'Package Lines')
    company_id = fields.Many2one('res.company', 'Company', default=lambda self: self.env.company, required=True)
    destination_internal_transfer_ids = fields.One2many('stock.picking', 'internal_transfer_scanner_id',
                                                        'Destination Transfers')
    destination_internal_transfer_count = fields.Integer('Destination Internal Transfers',
                                                         compute='_compute_internal_transfer_count', copy=False)
    location_dest_package_count = fields.Integer('Destination Boxes', compute="_compute_location_dest_package_count", copy=False)
    scanned_packages_count = fields.Integer('Scanned lines', compute='_compute_scanned_packages_count', copy=False)
    package_limit = fields.Integer('Package Limit', default=_get_package_limit, readonly=True, copy=False)
    scanned_index = fields.Integer('Scanned Index', default=1, copy=False)
    available_packages_count = fields.Integer('Available Boxes', compute='_compute_available_packages_count', copy=False)
    operation_type_id = fields.Many2one('stock.picking.type', 'Operation')
    operation_type = fields.Selection(string='Internal Transfer Type',
                                      related='operation_type_id.internal_transfer_type')
    scan_toggle = fields.Boolean('ADD', default=True)
    warehouse_id = fields.Many2one('stock.warehouse', related='operation_type_id.warehouse_id')
    available_product_count = fields.Integer('Destination Products', compute="_compute_available_product_count", copy=False)
    inventory_adjusted = fields.Boolean('Inventory Adjusted', copy=False)
    readonly_locations = fields.Boolean('Readonly Locations', copy=False, compute="_ks_compute_readonly_locations")
    self_assigned = fields.Boolean('Self Assigned', compute="_ks_compute_self_assigned")
    product_lines_to_suspense = fields.One2many('product.line.suspense', 'internal_transfer_scanner_id')
    free_bin = fields.Boolean('Free Bin?', copy=False)
    free_negative_bin = fields.Boolean('Free Negative Bin?', copy=False)
    readonly_free_negative_bin = fields.Boolean('Readonly Free Negative Bin?', copy=False)
    is_quant_negative = fields.Boolean('Is Quant Negative at Destination?', copy=False, compute='ks_check_negative_quant')
    validate_by_cron = fields.Boolean(string='Validate By Cron', copy=False)

    def write(self, vals):
        if 'validate_by_cron' in vals and vals.get('validate_by_cron') == True:
            self.with_context(ks_validate_by_cron=True).ks_action_validate()
        return super(InternalTransferScanner, self).write(vals)

    @api.onchange('location_dest_id', 'operation_type_id')
    def ks_check_negative_quant(self):
        stock_quant = self.env['stock.quant']
        for rec in self:
            if rec.operation_type_id and rec.operation_type_id.internal_transfer_type == 'immediate_unpack' and rec.location_dest_id:
                is_negative_quant = stock_quant.search_count(
                    [('location_id', '=', rec.location_dest_id.id), ('quantity', '<', 0)]) > 0
                rec.is_quant_negative = is_negative_quant
            else:
                rec.is_quant_negative = False

    def _ks_compute_self_assigned(self):
        for record in self:
            record.self_assigned = True if record.assigned_worker_id.id == self.env.uid else False

    @api.depends('internal_transfer_scanner_lines')
    def _ks_compute_readonly_locations(self):
        for record in self:
            readonly_locations = False
            if record.operation_type_id.internal_transfer_type in ['physical_audit_product', 'immediate_loose']:
                if record.internal_transfer_scanner_lines or record.product_lines_to_suspense or record.free_bin:
                    readonly_locations = True
            record.readonly_locations = readonly_locations

    def ks_action_assign(self):
        self.ensure_one()
        if self.state == 'cancel':
            raise UserError(_("%s warehouse transfer is already cancelled." % self.name))
        if self.state == 'moved':
            raise UserError(_("%s warehouse transfer is already moved." % self.name))
        self.with_context(assign=True).check_location_validation_warnings()
        self.check_diff_warehouse_warning()
        action = self.env['ir.actions.actions']._for_xml_id('ks_barcode_extension.internal_transfer_assigned_action')
        action['context'] = {'active_ids':self.env.context.get('active_ids', [])}
        return action

    @api.depends('operation_type_id', 'location_dest_id')
    def _compute_available_product_count(self):
        for record in self:
            quantity = 0
            if record.operation_type_id.internal_transfer_type in ['immediate_unpack', 'immediate_loose'] \
                    and record.location_dest_id:
                quants = self.env['stock.quant'].search([('location_id', '=', record.location_dest_id.id),
                                                         ('package_id', '=', None)])
                quantity = sum(quants.mapped('quantity'))
            record.available_product_count = quantity

    @api.depends('internal_transfer_scanner_lines.physically_available')
    def _compute_available_packages_count(self):
        for record in self:
            available_lines = record.internal_transfer_scanner_lines.filtered(lambda line: line.physically_available)
            record.available_packages_count = len(available_lines)

    @api.onchange('operation_type_id')
    def _onchange_operation_type_id(self):
        if self.operation_type_id:
            if self.operation_type_id.internal_transfer_type in ['immediate_unpack', 'immediate_transfer']:
                self.location_id = False
            elif self.operation_type_id.internal_transfer_type == 'physical_audit_product':
                self.location_dest_id = False

    @api.onchange('location_id')
    def _onchange_location_id(self):
        if self.operation_type_id.internal_transfer_type in ['whole_stock', 'physical_audit']:
            if self.internal_transfer_scanner_lines:
                lines_to_delete = [(2, line.id) for line in self.internal_transfer_scanner_lines]
                self.internal_transfer_scanner_lines = lines_to_delete

    @api.depends('location_dest_id')
    def _compute_location_dest_package_count(self):
        """
        On the change of the location_dest_id field destination packages count is updated.
        """
        for record in self:
            quants_count = self.env['stock.quant'].search_count([('location_id', '=', record.location_dest_id.id),
                                                                 ('package_id', '!=', None),
                                                                 ('quantity', '>', 0)])
            record.location_dest_package_count = quants_count

    @api.depends('internal_transfer_scanner_lines')
    def _compute_scanned_packages_count(self):
        """
        On the change of the internal_transfer_scanner_lines the scanned packages count is updated.
        """
        for record in self:
            scanned_lines = []
            if record.operation_type_id.internal_transfer_type != 'physical_audit_product':
                scanned_lines = record.internal_transfer_scanner_lines.filtered(lambda line: line.package_id)
            record.scanned_packages_count = len(scanned_lines)

    @api.depends('destination_internal_transfer_ids')
    def _compute_internal_transfer_count(self):
        """
        Compute the destination internal transfer count.
        return: None
        """
        for record in self:
            record.destination_internal_transfer_count = len(record.destination_internal_transfer_ids)

    @api.model
    def create(self, vals):
        """
        Update the name with the sequence if not name or name is 'New'.
        return: record id
        """
        if not vals.get('name') or vals.get('name') == _('New'):
            vals['name'] = self.env['ir.sequence'].next_by_code('internal_transfer_scanner')
        return super(InternalTransferScanner, self).create(vals)

    def get_reserved_package_domain(self):
        """
        Create the domain to check the input package is already reserved or not.
        If the package_id is present in the context then search with the source and destination package with the
        package_id.
        If the load_all_stock in the context then create the domain where source or destination package is available.
        Else use the add package value.
        return: domain
        """
        package_id = self._context.get('package_id')
        if package_id:
            domain = expression.OR([[('package_id', '=', package_id)],
                                    [('result_package_id', '=', package_id)]])
        elif self._context.get('load_all_stock'):
            domain = expression.OR([[('package_id', '!=', None)],
                                    [('result_package_id', '!=', None)]])
            domain = expression.AND([domain, [('location_id', '=', self.location_id.id)]])
        else:
            domain = expression.OR([[('package_id', '=', self.package_id)],
                                    [('result_package_id', '=', self.package_id)]])
        domain = expression.AND([domain, [('state', 'in', ['partially_available', 'assigned'])]])
        return domain

    def ks_prepare_reserved_packages_vals(self, move_line):
        return {
            'move_id': move_line.move_id.id,
            'move_line_id': move_line.id,
            'picked': move_line.package_level_id.picked,
            'done': move_line.package_level_id.is_done,
        }

    def check_reserved_move(self, package_id):
        domain = self.with_context(package_id=package_id.id).get_reserved_package_domain()
        stock_move_line_ids = self.env['stock.move.line'].search(domain)
        reserved_moves = []
        if stock_move_line_ids:
            picked_package_level = stock_move_line_ids.mapped('package_level_id').filtered(lambda line: line.picked)
            if self.operation_type_id.internal_transfer_type == 'immediate_unpack' and picked_package_level:
                transfer_name = picked_package_level.mapped('picking_id').mapped('name')
                if transfer_name:
                    raise UserError(_('%s package with %s blp is already picked in %s'
                                      % (self.package_id.name, self.package_id.x_blp, ', '.join(transfer_name))))
            else:
                for move_line in stock_move_line_ids:
                    reserved_moves.append((0, 0, self.ks_prepare_reserved_packages_vals(move_line)))
        return reserved_moves

    def prepare_scanned_package_vals(self, scanned_record):
        """
        Prepare the vals to create the scanner line.
        If the package_id is false then use the add package field value else use the argument value.
        package_id: Takes the package id to create the vals.
        return: dict of vals
        """
        self.ensure_one()
        vals = {
            'scanned': True,
            'internal_transfer_scanner_id': self.id,
        }
        if self.env.context.get('add_product'):
            if self.operation_type_id.internal_transfer_type == 'physical_audit_product':
                if not self.location_id:
                    vals['need_update'] = True
            else:
                vals['quantity'] = 1
            vals['product_id'] = scanned_record.id
        else:
            reserved_move_ids = self.check_reserved_move(scanned_record)
            vals.update({'package_reserved_move_ids': reserved_move_ids,
                         'package_id': scanned_record.id})
        return vals

    def check_package_limit(self):
        """
        It can check the package limit as well as the length of the internal_transfer_scanner_lines.
        return: If the get_limit is present in the context then return the limit else return error.
        """
        packages_limit = self.env['ir.config_parameter'].sudo().get_param('ks_barcode_extension.packages_limit', 40)
        if not isinstance(packages_limit, int):
            packages_limit = int(packages_limit)
        if self._context.get('get_limit'):
            return packages_limit
        if len(self.internal_transfer_scanner_lines) >= packages_limit:
            return _("Package limit is exceeding.")

    def ks_check_package_existing_internal_transfer(self, package_id):
        self.ensure_one()
        internal_transfers_line = self.env['internal.transfer.scanner.line'].sudo().\
            search([('package_id', '=', package_id.id), ('state', '=', 'assigned'),
                    ('internal_transfer_scanner_id', '!=', self.id)])
        if internal_transfers_line:
            internal_transfers = internal_transfers_line.mapped('internal_transfer_scanner_id')
            return ','.join(internal_transfers.mapped('name'))
        return None

    def add_package(self):
        if self.package_id:
            warning = self._ks_add_package(self.package_id, self.package_id.x_blp)
            if warning:
                raise UserError(warning)
            self.package_id = None

    def remove_package(self):
        if self.remove_package_id:
            warning = self._ks_remove_package(self.remove_package_id)
            if warning:
                raise UserError(warning)
            self.remove_package_id = None

    def prepare_process_status(self, status, message):
        """
        status: status will be True or False
        message: would be any string need to shows in the popup.
        return: dictionary with the key of status and message
        """
        return {
            'status': status,
            'message': message
        }

    def ks_action_process(self, barcode):
        """
        barcode: scanned process barcode.
        This method is called from the process barcode field on the scanning of the process barcodes then prform the
        operations accordingly.
        return: success or error messages.
        """
        process_barcode = self.env.ref('ks_barcode_extension.internal_transfer_process_barcodes_default')
        action = False
        if process_barcode:
            if self.state == 'moved':
                status, message = False, _("You are not allowed to process the moved warehouse transfer.")
            elif self.state == 'cancel':
                status, message = False, _("You are not allowed to process the cancelled warehouse transfer.")
            else:
                if barcode == process_barcode.action_cancel:
                    try:
                        self.action_cancel()
                        status, message = True, _("Cancel has been executed.")
                    except Exception as Error:
                        status, message = False, Error
                elif barcode == process_barcode.action_validate:
                    if self.state == 'assigned':
                        try:
                            result = self.ks_action_validate()
                            if isinstance(result, dict):
                                action = result
                            status, message = True, _("%s transfer has been validated." % self.name)
                        except Exception as Error:
                            status, message = False, Error
                    else:
                        status, message = False, _("Please Assign the warehouse transfer to Validate.")
                elif barcode == process_barcode.action_assign_to_me:
                    if not self.self_assigned and self.state not in ['cancel', 'moved']:
                        try:
                            result = self.ks_action_assign_to_me()
                            if isinstance(result, dict):
                                action = result
                            status, message = True, _("Transfer has been assigned to self")
                        except Exception as Error:
                            status, message = False, Error
                    else:
                        status, message = False, _("Transfer may be already assigned to self.")
                elif barcode == process_barcode.action_load_product:
                    if self.operation_type in ['physical_audit_product', 'immediate_loose'] and self.state == 'assigned':
                        try:
                            result = self.ks_action_load_products()
                            if isinstance(result, dict):
                                action = result
                            status, message = True, _("Load Product Executed")
                        except Exception as Error:
                            status, message = False, Error
                    else:
                        status, message = False, _("Invalid O.T. for the Load Product or may be State is in Assigned.")
                elif barcode == process_barcode.action_load_boxes:
                    if self.operation_type in ['whole_stock', 'physical_audit'] and self.state == 'assigned':
                        try:
                            result = self.action_load_source_location_packages()
                            if isinstance(result, dict):
                                action = result
                            status, message = True, _("Load Source Boxes Executed")
                        except Exception as Error:
                            status, message = False, Error
                    else:
                        status, message = False, _("Invalid Operation Type for Load Source Boxes or may be state not in assigned.")
                else:
                    status, message = False, _("Process is not defined with this %s barcode" % barcode)
        else:
            status, message = False, _("Processes are not defined.")
        res = self.prepare_process_status(status, message)
        if action:
            res['action'] = action
        return res

    def validate_internal_transfers(self, internal_transfers):
        """
        This method is used to validate the internal transfers. If any validation is comes up then log the error.
        internal_transfer: object of the internal_transfer with the ids.
        return: None
        """
        self.ensure_one()
        try:
            internal_transfers.button_validate()
        except Exception as error:
            raise UserError(error)

    def ks_check_validate_warning(self):
        if self.operation_type_id.internal_transfer_type in ['immediate_transfer', 'immediate_unpack']:
            if not self.location_dest_id:
                raise UserError(_("You need to select a destination location to proceed."))
        elif self.operation_type_id.internal_transfer_type == 'physical_audit_product':
            if not self.location_id:
                raise UserError(_("You need to select a source location to proceed."))
        else:
            if not self.location_id:
                raise UserError(_("You need to select a source location to proceed."))
            if not self.location_dest_id:
                raise UserError(_("you need to select a destination location to proceed."))

    def check_location_validation_warnings(self):
        self.ensure_one()
        if not self.operation_type_id:
            raise UserError(_("Select the operation type to proceed."))
        if not self.operation_type_id.internal_transfer_type:
            raise UserError(_("Internal transfer type is not selected in the operation type."))
        if not self.env.context.get('assign'):
            self.ks_check_validate_warning()
        if self.operation_type_id.internal_transfer_type in ['immediate_unpack', 'physical_audit_product',
                                                             'immediate_loose']:
            if self.location_id:
                if self.operation_type_id.internal_transfer_type in ['physical_audit_product', 'immediate_loose']:
                    warning = self.with_context(check_empty_open_location=True).\
                        ks_check_open_product_location(self.location_id, 'bin')
                    if warning:
                        raise UserError(warning)
            if self.location_dest_id:
                if self.operation_type_id.internal_transfer_type in ['immediate_unpack', 'immediate_loose']:
                    warning = self.ks_check_open_product_location(self.location_dest_id, 'bin')
                    if warning:
                        raise UserError(warning)
        else:
            if self.operation_type_id.internal_transfer_type != 'immediate_transfer':
                if self.location_id and self.location_id.is_open_location:
                    raise UserError(_("You selected source location as the open location."))
                if self.location_id and self.location_id.with_context(packages=True).ks_check_is_empty_location():
                    raise UserError(_("Your selected source location is empty location."))
            if self.location_dest_id and self.location_dest_id.is_open_location:
                raise UserError(_("You selected Destination location as the open location."))

    def ks_create_internal_transfer(self, transfer_type):
        self.ensure_one()
        internal_transfer_vals = self.prepare_internal_transfer_values()
        if transfer_type == 'immediate':
            internal_transfer_vals.update({'immediate_transfer': True})
        internal_transfer_id = self.env['stock.picking'].create(internal_transfer_vals)
        return internal_transfer_id

    def _ks_action_validate(self):
        transfer_type = self.env['ir.config_parameter'].sudo().get_param('ks_barcode_extension.transfer_type',
                                                                         'immediate')
        for record in self:
            if record.operation_type_id.internal_transfer_type == 'physical_audit_product':
                if record.free_bin:
                    record.ks_transfer_bin_stock_to_suspense()
                else:
                    record.internal_transfer_scanner_lines.with_context(from_warehouse_transfer=True,
                                                                        new_location_id=record.get_location_id()).ks_action_adjust_inventory()
                    record.internal_transfer_scanner_lines.ks_transfer_to_suspense()
                    if record.product_lines_to_suspense:
                        record.ks_transfer_bin_stock_to_suspense()
            else:
                if record.operation_type_id.internal_transfer_type == 'immediate_transfer' and not self.env.context.get('ks_solo_sku'):
                    check_solo_sku = record.check_solo_sku()
                    if check_solo_sku:
                        return record.check_solo_sku()
                transfer_id = record.ks_create_internal_transfer(transfer_type)
                if record.operation_type_id.internal_transfer_type == 'immediate_transfer':
                    record.internal_transfer_scanner_lines.ks_transfer_packages(transfer_id)
                elif record.operation_type_id.internal_transfer_type == 'whole_stock':
                    record.internal_transfer_scanner_lines.ks_transfer_packages(transfer_id)
                elif record.operation_type_id.internal_transfer_type == 'physical_audit':
                    record.internal_transfer_scanner_lines.ks_create_physical_audit_stock_move_lines(transfer_id, transfer_type)
                elif record.operation_type_id.internal_transfer_type == 'immediate_unpack':
                    record.internal_transfer_scanner_lines.ks_create_immediate_unpack_move_lines(transfer_id)
                elif record.operation_type_id.internal_transfer_type == 'immediate_loose':
                    record.internal_transfer_scanner_lines.ks_transfer_loose_products(transfer_id)
                else:
                    raise UserError(_("Invalid operation"))
            transfers = record.destination_internal_transfer_ids.\
                filtered(lambda transfer: transfer.state not in ['cancel', 'done'])
            if transfers:
                record.validate_internal_transfers(transfers)
            if record.operation_type_id.internal_transfer_type not in ['physical_audit_product', 'immediate_loose']:
                if record.operation_type_id.internal_transfer_type == 'immediate_unpack':
                    record.internal_transfer_scanner_lines.ks_action_reserve_unpack_lines()
                else:
                    record.internal_transfer_scanner_lines.action_reserve_lines()
            record.message_post(body=record._create_message_to_post('moved'))
            record.state = 'moved'
            return True

    def get_location_id(self):
        self.ensure_one()
        return self.operation_type_id.warehouse_id.suspense_location_id

    def check_solo_sku(self):
        self.ensure_one()
        is_admin_user = self.env.user.has_group('ks_barcode_extension.warehouse_transfer_manager')
        scanned_package_sku = self.internal_transfer_scanner_lines.mapped('product_ids')
        is_solo_sku = scanned_package_sku.filtered(lambda product: product.is_solo_sku)
        not_solo_sku = scanned_package_sku.filtered(lambda product: not product.is_solo_sku)
        if len(is_solo_sku) > 1 or (is_solo_sku and not_solo_sku):
            if is_admin_user:
                confirmation_message = "These product SKUs cannot be transferred together. Are you sure you want to proceed?"
            else:
                confirmation_message = "These product SKUs cannot be transferred together. Please send to admin for approval."
            action = self.env['ir.actions.actions']._for_xml_id(
                'ks_barcode_extension.solo_product_confirmation_action')
            action['context'] = {'default_message': confirmation_message,
                                 'default_internal_transfer_scanner_id': self.id}
            return action


    def prepare_internal_transfer_values(self):
        """
        This method can prepare the internal transfer values.
        return: dict of values
        """
        self.ensure_one()
        destination_location = self.location_dest_id.id or self.operation_type_id.default_location_dest_id.id
        source_location = self.location_id.id or self.operation_type_id.default_location_src_id.id
        if self.env.context.get('suspense'):
            suspense_location = self.operation_type_id.warehouse_id.suspense_location_id
            if not suspense_location:
                raise UserError(_("Suspense location is not found. Configure the suspense location for %s warehouse."
                                  % self.operation_type_id.warehouse_id.name))
            destination_location = suspense_location.id
            if self.operation_type_id.internal_transfer_type in ['immediate_unpack', 'immediate_loose']:
                source_location = self.location_dest_id.id
        vals = {
            'picking_type_id': self.operation_type_id.id,
            'location_id': source_location,
            'location_dest_id': destination_location,
            'company_id': self.company_id.id,
            'origin': self.name,
            'internal_transfer_scanner_id': self.id
        }
        return vals

    def _get_action_view_picking(self, transfers):
        """
        transfers: create the domain to add the action on the transfers.
        return: action used to open internal transfers form or tree view.
        """
        action = self.env["ir.actions.actions"]._for_xml_id("stock.action_picking_tree_all")
        if len(transfers) > 1:
            action['domain'] = [('id', 'in', transfers.ids)]
        elif transfers:
            form_view = [(self.env.ref('stock.view_picking_form').id, 'form')]
            if 'views' in action:
                action['views'] = form_view + [(state, view) for state, view in action['views'] if view != 'form']
            else:
                action['views'] = form_view
            action['res_id'] = transfers.id
        return action

    def action_view_internal_transfers(self):
        """
        If the destination internal transfers is available for the scanner then open it else raise UserError.
        return: action to open the picking view.
        """
        transfer_ids = self.destination_internal_transfer_ids
        if not transfer_ids:
            raise UserError(_("There is no internal transfers created. First validate then try again to open the"
                              "internal transfers."))
        return self._get_action_view_picking(transfer_ids)

    def action_load_source_location_packages(self):
        """
        This method can add the packages without exceeding the package limit to the scanner lines of the source
        location is selected in the form view.
        This method is applied only if the whole stock is checked.
        If no packages are available on the source or all packages are added then raise the UserError.
        return: None
        """
        package_obj = self.env['stock.quant.package']
        for record in self:
            if not record.location_id:
                raise UserError(_("Select the source location to load the packages."))
            package_limit = record.with_context(get_limit=True).check_package_limit()
            scanned_packages_len = len(record.internal_transfer_scanner_lines)
            add_package_limit = package_limit - scanned_packages_len
            if add_package_limit <= 0:
                raise UserError(_("Pacakge Limit is exceeding."))
            package_ids = package_obj.search([('location_id', '=', record.location_id.id)])
            if not package_ids:
                raise UserError(_("You don't have any package on %s location." % self.location_id.name))
            packages_to_add = package_obj
            add_pack_count = 0
            scanned_transfers = []
            for package_id in package_ids:
                if add_pack_count == add_package_limit:
                    break
                if not record.internal_transfer_scanner_lines.\
                        filtered(lambda line: package_id.id == line.package_id.id):
                    scanned_transfer_name = self.ks_check_package_existing_internal_transfer(package_id)
                    if scanned_transfer_name:
                        scanned_transfers.append(scanned_transfer_name)
                        continue
                    packages_to_add |= package_id
                    add_pack_count += 1
            if not packages_to_add:
                if scanned_transfers:
                    raise UserError(_("All Packages of the %s location is already scanned in %s."
                                      % (self.location_id.display_name, ', '.join(set(scanned_transfers)))))
                raise UserError(_("All packages are already added."))
            scanned_line_vals = []
            for package_id in packages_to_add:
                scanned_line_vals.append((0, 0, record.prepare_scanned_package_vals(package_id)))
            record.internal_transfer_scanner_lines = scanned_line_vals

    def action_remove_all_source_location_packages(self):
        """
        This can remove all the scanned packages from the lines.
        This method can applied if the whole stock is checked.
        If there is nothing to remove then raise UserError.
        return: None
        """
        for record in self:
            if not record.internal_transfer_scanner_lines and not record.product_lines_to_suspense and not record.free_bin and not record.free_negative_bin:
                raise UserError(_('There is nothing to remove.'))
            if record.internal_transfer_scanner_lines:
                lines_to_remove = [(2, scanner_line.id) for scanner_line in record.internal_transfer_scanner_lines]
                record.internal_transfer_scanner_lines = lines_to_remove
            if record.product_lines_to_suspense:
                product_lines_to_remove = [(2, pl.id) for pl in record.product_lines_to_suspense]
                record.product_lines_to_suspense = product_lines_to_remove
            if record.free_bin:
                record.free_bin = False
            if record.free_negative_bin:
                record.free_negative_bin = False
            if record.readonly_free_negative_bin:
                record.readonly_free_negative_bin = False
            if record.validate_by_cron:
                record.validate_by_cron = False

    def _create_message_to_post(self, state):
        """
        state: Update state
        This method can create message shows in the chatter in the view.
        return: Message with the states
        """
        return _("Internal transfer scanner state changed: <b>%s -> %s</b>" % (self.state.upper(), state.upper()))

    def action_cancel(self):
        """
        This method can cancel the scanner.
        If the state is moved then raise UserError.
        If the state already in cancelled state then raise UserError.
        Add the status of the states to the chatter.
        return None.
        """
        for record in self:
            if record.state == 'moved':
                raise UserError(_("Unable to cancel %s transfer. This transfer is already moved." % record.name))
            elif record.state == 'cancel':
                raise UserError(_('%s transfer is already cancelled.' % record.name))
            record.message_post(body=record._create_message_to_post('cancel'))
            record.state = 'cancel'

    def ks_prepare_packages_confirmation_message(self):
        message = ''
        if not self.location_dest_id.restrict_limit or self.location_dest_id.package_limit <= 0:
            return message
        location_dest_count_after_move = self.location_dest_package_count + self.scanned_packages_count
        if location_dest_count_after_move > self.location_dest_id.package_limit:
            message += _("You are transferring %s packs which makes the resultant quantity after the transfer %s,"
                         " which exceeds the storage limit of the destination location %s, please confirm to proceed."
                         % (self.scanned_packages_count, location_dest_count_after_move,
                            self.location_dest_id.package_limit))
        elif self.location_dest_package_count:
            message += _("There are %s boxes at location %s. " % (self.location_dest_package_count,
                                                                  self.location_dest_id.display_name))
            message += _("You are about to move %s boxes, " % self.scanned_packages_count)
            message += _("Which will make it a total %s boxes. " % location_dest_count_after_move)
        return message

    def ks_calculate_dest_product_count(self):
        self.ensure_one()
        if self.operation_type_id.internal_transfer_type == 'immediate_unpack':
            package_ids = self.internal_transfer_scanner_lines.mapped('package_id')
            quantity = package_ids.mapped('quant_ids').mapped('quantity')
            product_count = sum(quantity)
        elif self.operation_type_id.internal_transfer_type == 'immediate_loose':
            quantity = self.internal_transfer_scanner_lines.mapped('physically_available_qty')
            product_count = sum(quantity)
        else:
            quantity = self.internal_transfer_scanner_lines.mapped('quantity')
            product_count = sum(quantity)
        return product_count

    def prepare_product_confirmation_message(self):
        message = ''
        if not self.location_dest_id.restrict_limit or self.location_dest_id.product_limit <= 0:
            return message
        location_dest_count = self.ks_calculate_dest_product_count()
        location_dest_count_after_move = location_dest_count + self.available_product_count
        if location_dest_count_after_move > self.location_dest_id.product_limit:
            message += _("You are transferring %s products which makes the resultant quantity after the transfer %s,"
                         " which exceeds the storage limit of the destination location %s, please confirm to proceed."
                         % (location_dest_count, location_dest_count_after_move,
                            self.location_dest_id.product_limit))
        elif self.available_product_count:
            message += _("There are %s products at location %s." % (self.available_product_count,
                                                                    self.location_dest_id.display_name))
            message += _("You are about to move %s products, " % location_dest_count)
            message += _("Which will make it a total %s product. " % location_dest_count_after_move)
        return message

    def check_diff_warehouse_warning(self):
        transfer_warehouse = self.env['ir.config_parameter'].sudo().get_param('ks_barcode_extension.internal_transfer_type', 'intra')
        diff_warehouse_lines = False
        if self.location_dest_id:
            diff_warehouse_lines = self.internal_transfer_scanner_lines.\
                filtered(lambda line: line.package_id and line.location_id.warehouse_id.id != self.location_dest_id.warehouse_id.id)
        if transfer_warehouse == 'intra':
            warning = _("You can only able to perform intra transfer.")
            if self.location_id and self.location_dest_id:
                if self.location_id.warehouse_id.id != self.location_dest_id.warehouse_id.id:
                    raise UserError(warning)
            if diff_warehouse_lines:
                index = 1
                for dwl in diff_warehouse_lines:
                    warning += _("\n%s. %s with %s blp is at the different warehouses."
                                 % (index, dwl.package_id.name, dwl.package_id.x_blp))
                    index += 1
                raise UserError(warning)
        else:
            warning = _("You are allowed to perform inter transfer but some scanned packages are manually picked:")
            if diff_warehouse_lines:
                reserved_diff_warehouse_lines = diff_warehouse_lines.filtered(lambda line: line.package_reserved_move_ids)
                pick_warning = ""
                index = 1
                for reserved_line in reserved_diff_warehouse_lines:
                    pick_line = reserved_line.package_reserved_move_ids.filtered(lambda rl: rl.picked)
                    if pick_line:
                        pick_warning += _("\n%s. %s with %s blp is already picked."
                                     % (index, reserved_line.package_id.name, reserved_line.package_id.x_blp))
                        index += 1
                if pick_warning:
                    warning += pick_warning
                    raise UserError(warning)

    def prepare_confirmation_message(self):
        if self.operation_type_id.internal_transfer_type == 'physical_audit_product':
            confirmation_message = ''
        elif self.operation_type_id.internal_transfer_type in ['immediate_unpack', 'immediate_loose']:
            confirmation_message = self.prepare_product_confirmation_message()
        else:
            confirmation_message = self.ks_prepare_packages_confirmation_message()
        return confirmation_message

    def ks_check_similar_product_warning(self):
        self.ensure_one()
        if self.operation_type_id.internal_transfer_type == 'immediate_unpack':
            package_ids = self.internal_transfer_scanner_lines.mapped('package_id')
            product_ids = package_ids.mapped('quant_ids').mapped('product_id')
        else:
            product_ids = self.internal_transfer_scanner_lines.mapped('product_id')
        if len(product_ids) > 1 and self.operation_type_id.internal_transfer_type == 'immediate_unpack':
            warning = _("You've scanned packages of the multiple products.")
            index = 1
            for product_id in product_ids:
                product_quants = package_ids.mapped('quant_ids').filtered(lambda quant: quant.product_id.id == product_id.id)
                package_blp = product_quants.mapped('package_id').mapped('x_blp')
                warning += _("\n%s. %s - %s " % (index, product_id.default_code, ','.join(package_blp)))
                index += 1
            raise UserError(warning)
        if self.available_product_count > 0 and self.location_dest_id.quant_ids:
            unmatched_prod_quants = self.location_dest_id.quant_ids.\
                filtered(lambda quant: quant.product_id.id not in product_ids.ids and quant.quantity > 0)
            if unmatched_prod_quants:
                confirmation_line_vals = []
                multi_location = self.warehouse_id.multi_location_pick
                for prod_quant in unmatched_prod_quants:
                    confirmation_line_vals.append((0, 0, self.ks_get_product_quantity_vals(prod_quant, multi_location)))
                warning = _("You have multiple products at the %s location.\nThe different SKU's quantity will be "
                            "transferred to the Lost & Found location after this operation."
                            % self.location_dest_id.display_name)
                action = self.env['ir.actions.actions']._for_xml_id(
                    'ks_barcode_extension.internal_transfer_scanner_confirmation_action')
                action['context'] = {'default_name': warning,
                                     'default_lines_confirmation': True,
                                     'default_confirmation_line_ids': confirmation_line_vals,
                                     'default_internal_transfer_scanner_id': self.id}
                return action
        return None

    def ks_action_validate(self):
        self.ensure_one()
        self.check_location_validation_warnings()
        self.check_diff_warehouse_warning()
        nothing_to_add = False
        if self.operation_type_id.internal_transfer_type == 'physical_audit_product':
            if not self.internal_transfer_scanner_lines and not self.free_bin:
                nothing_to_add = True
            elif self.internal_transfer_scanner_lines:
                available_lines = self.internal_transfer_scanner_lines.\
                    filtered(lambda line: line.physically_available_qty > 0 or line.on_hand_qty > 0)
                if not available_lines and not self.free_negative_bin:
                    nothing_to_add = True
        else:
            if not self.internal_transfer_scanner_lines:
                nothing_to_add = True
        if nothing_to_add:
            raise UserError(_("There is nothing to validate. Add some lines or update the new onhand quantity to"
                              " validate."))
        confirmation_message = False
        if self.operation_type_id.internal_transfer_type in ['immediate_unpack', 'immediate_loose']:
            confirmation_message = self.ks_check_similar_product_warning()
            if isinstance(confirmation_message, dict):
                return confirmation_message
        if not confirmation_message:
            confirmation_message = self.prepare_confirmation_message()
        if confirmation_message:
            action = self.env['ir.actions.actions']._for_xml_id(
                'ks_barcode_extension.internal_transfer_scanner_normal_confirmation_action')
            action['context'] = {'default_name': confirmation_message,
                                 'default_internal_transfer_scanner_id': self.id}
            return action
        if not self.env.context.get('ks_validate_by_cron'):
            return self._ks_action_validate()

    def ks_set_operation_type(self, barcode):
        status, message = False, _("No barcode found. Please scan again.")
        if not barcode:
            return self.prepare_process_status(status, message)
        operation_type_id = self.env['stock.picking.type'].search([('barcode', '=', barcode)], limit=1, order='id ASC')
        if not operation_type_id:
            status, message = False, _("No operation type is found with %s barcode" % barcode)
        elif not operation_type_id.internal_transfer_type:
            status, message = False, _("%s operation type has not internal transfer type." % barcode)
        elif operation_type_id.warehouse_id.id != self.env.user.property_warehouse_id.id:
            status, message = False, _("Scanned %s operation type is not for %s warehouse"
                                       % (barcode, self.env.user.property_warehouse_id.name))
        else:
            self.operation_type_id = operation_type_id.id
            status, message = True, _("Operation type is updated with %s barcode." % barcode)
        if operation_type_id.internal_transfer_type in ['immediate_transfer', 'immediate_unpack']:
            self.location_id = None
        if operation_type_id.internal_transfer_type == 'physical_audit_product':
            self.location_dest_id = None
        return self.prepare_process_status(status, message)

    def add_destination_location(self):
        if self.location_dest_id:
            # warning = self.ks_check_location_warnings(self.location_dest_id, self.location_dest_id.barcode)
            warning = False
            if warning:
                raise UserError(warning)


    def ks_scan_location(self, barcode):
        status, message = False, _("No barcode found. Please scan again.")
        if not barcode:
            return self.prepare_process_status(status, message)
        location_id = self.env['stock.location'].search([('barcode', '=', barcode)], limit=1, order='id ASC')
        warning = self.ks_check_location_warnings(location_id, barcode)
        if warning:
            status, message = False, warning
        else:
            location_type = self.ks_set_location(location_id.id)
            if location_type:
                status, message = True, _("%s Location is updated with %s barcode." % (location_type, barcode))
            else:
                status, message = False, _("Locations are not allowed to update.")
        return self.prepare_process_status(status, message)

    def ks_set_location(self, location_id):
        if self.operation_type_id.internal_transfer_type in ['immediate_transfer', 'immediate_unpack']:
            self.location_dest_id = location_id
            location_type = 'Destination'
        elif self.operation_type_id.internal_transfer_type == 'physical_audit_product':
            if not self.internal_transfer_scanner_lines and not self.free_bin:
                self.location_id = location_id
                location_type = 'Source'
            else:
                location_type = None
        else:
            if self.scanned_index % 2 == 0:
                self.location_dest_id = location_id
                location_type = 'Destination'
            else:
                is_update = True
                if self.operation_type_id.internal_transfer_type == 'immediate_loose' and self.internal_transfer_scanner_lines:
                    is_update = False
                if is_update:
                    self.location_id = location_id
                    location_type = 'Source'
                else:
                    self.location_dest_id = location_id
                    location_type = 'Destination'
            self.scanned_index += 1
        return location_type

    def ks_check_location_warnings(self, location_id, barcode):
        warning = False
        if self.operation_type_id.internal_transfer_type == 'physical_audit_product' and self.internal_transfer_scanner_lines:
            warning = _("Locations are not allowed to changed if the product are loaded to the warehouse"
                        " transfer.")
        elif not location_id:
            warning = _("No location is found with %s barcode" % barcode)
        # elif location_id.usage != 'internal':
        #     warning = _("%s location is not internal location" % barcode)
        elif self.operation_type_id.internal_transfer_type == 'immediate_transfer' and self.internal_transfer_scanner_lines:
            warning = self.ks_check_scanned_package_sku(location_id, barcode)
        elif self.operation_type_id:
            if self.operation_type_id.internal_transfer_type in ['physical_audit_product', 'immediate_unpack', 'immediate_loose']:
                warning = self.ks_check_open_product_location(location_id, 'bin')
            else:
                if self.operation_type_id.internal_transfer_type in ['whole_stock', 'physical_audit']:
                    if self.scanned_index % 2 != 0:
                        if location_id.with_context(packages=True).ks_check_is_empty_location():
                            warning = _("%s location is empty." % barcode)
                if location_id.is_open_location:
                    warning = _("%s location is an open location." % barcode)
        return warning

    def ks_check_scanned_package_sku(self, location_id, barcode):
        if location_id.restrict_multi_sku:
            scanned_package_sku = self.internal_transfer_scanner_lines.mapped('product_ids')
            product_reserved = self.env['stock.quant'].search([
                ('location_id', '=', location_id.id)
            ]).mapped('product_id')

            products_in_package_set = set(scanned_package_sku.ids)
            product_reserved_set = set(product_reserved.ids)

            # Check if all products_in_package are in product_reserved
            if product_reserved_set and not products_in_package_set.issubset(product_reserved_set):
                return _(f"Location {location_id.display_name} is reserved for another products and scanned packages contain different product.")
        return False


    def ks_check_open_product_location(self, location_id, open_type):
        self.ensure_one()
        warning = False
        if not location_id.is_open_location:
            warning = _("%s location is not an open location." % location_id.display_name)
        elif not location_id.open_location_type:
            warning = _("Open location type is not selected in %s location." % location_id.barcode)
        elif location_id.open_location_type != open_type:
            warning = _("You need to scan '%s' type location." % open_type)
        elif self.env.context.get('check_empty_open_location') and not self.operation_type_id.internal_transfer_type == 'physical_audit_product':
            if location_id.with_context(products=True).ks_check_is_empty_location():
                warning = _("%s location is empty." % location_id.barcode)
        return warning

    def ks_scan_package(self, barcode):
        status, message = False, _("No barcode found. Please scan again.")
        if not barcode:
            return self.prepare_process_status(status, message)
        package_id = self.env['stock.quant.package'].search([('x_blp', '=', barcode)])
        if self.env.context.get('scan_type') == 'add':
            warning = self._ks_add_package(package_id, barcode)
            status, message = True, _("%s package with %s blp is scanned." % (package_id.name, barcode))
        elif self.env.context.get('scan_type') == 'remove':
            warning = self._ks_remove_package(package_id)
            status, message = True, _("%s package with %s blp is removed." % (package_id.name, barcode))
        else:
            warning = _("Invalid operation. Please scan again.")
        if warning:
            status, message = False, warning
        return self.prepare_process_status(status, message)

    def _ks_add_package(self, package_id, barcode):
        warning = self.ks_check_basic_package_warnings(package_id, barcode)
        if warning:
            return warning
        scanned_line = self.internal_transfer_scanner_lines.filtered(lambda line: line.package_id.id == package_id.id)
        if scanned_line:
            warning = self.ks_process_scanned_line(scanned_line, package_id, barcode)
        else:
            if self.operation_type_id.internal_transfer_type == 'physical_audit':
                warning = self.check_package_limit()
            if not warning:
                self.internal_transfer_scanner_lines = [(0, 0, self.prepare_scanned_package_vals(package_id))]
        return warning

    def _ks_remove_package(self, package_id):
        scanned_line = self.internal_transfer_scanner_lines.filtered(lambda line: line.package_id.id == package_id.id)
        if scanned_line:
            if self.operation_type_id.internal_transfer_type == 'physical_audit':
                if scanned_line.physically_available:
                    self.internal_transfer_scanner_lines = [(1, scanned_line.id, {'physically_available': False})]
                else:
                    self.internal_transfer_scanner_lines = [(2, scanned_line.id)]
            else:
                self.internal_transfer_scanner_lines = [(2, scanned_line.id)]
            warning = None
        else:
            warning = _("%s package with %s blp is not scanned." % (package_id.name, package_id.x_blp))
        return warning

    def ks_process_scanned_line(self, scanned_line, package_id, barcode):
        if self.operation_type_id.internal_transfer_type == 'physical_audit':
            if scanned_line.physically_available:
                warning = _("%s package with %s blp is already scanned." % (package_id.name, barcode))
            else:
                self.internal_transfer_scanner_lines = [(1, scanned_line.id, {'physically_available': True})]
                warning = None
        else:
            warning = _("%s package with %s blp is already scanned." % (package_id.name, barcode))
        return warning

    def ks_check_basic_package_warnings(self, package_id, barcode):
        self.ensure_one()
        warning = self.check_package_limit()
        if warning and self.operation_type_id.internal_transfer_type != 'physical_audit':
            return warning
        if not package_id:
            return _("No package found with %s blp.", barcode)
        if not package_id.location_id:
            return _("%s package with %s blp have no location." % (package_id.name, barcode))
        if not package_id.quant_ids:
            return _("%s package with %s blp have no quants." % (package_id.name, barcode))
        if package_id.location_id.warehouse_id.id != self.env.user.property_warehouse_id.id:
            return _("%s package with %s BLP is not available at this warehouse." % (package_id.name, barcode))
        warnings = self.ks_check_package_sku(package_id, barcode)
        if warnings and self.operation_type_id.internal_transfer_type == 'immediate_transfer':
            return warnings
        transfer_name = self.ks_check_package_existing_internal_transfer(package_id)
        if transfer_name:
            transfer_id = self.env['internal.transfer.scanner'].search([('name', '=', transfer_name)])
            return _("%s package with %s BLP is already scanned in %s internal transfer, assigned to : %s"
                     % (package_id.name, barcode, transfer_name, transfer_id.assigned_worker_id.name))
        return None

    def ks_check_package_sku(self, package, barcode):
        products_in_package = package.quant_ids.mapped('product_id')
        product_reserved = self.env['stock.quant'].search([
            ('location_id', '=', self.location_dest_id.id),
            ('location_id.restrict_multi_sku', '=', True)
        ]).mapped('product_id')
        # Convert the lists to sets for comparison
        products_in_package_set = set(products_in_package.ids)
        product_reserved_set = set(product_reserved.ids)

        # Check if all products_in_package are in product_reserved
        if product_reserved_set and not products_in_package_set.issubset(product_reserved_set):
            return _(f"Location {self.location_dest_id.display_name} is reserved for another products.")

    def ks_check_product_existing_internal_transfer(self, product_id):
        self.ensure_one()
        existing_internal_transfer_lines = self.env['internal.transfer.scanner.line'].sudo(). \
            search([('product_id', '=', product_id.id), ('state', '=', 'assigned'),
                    ('internal_transfer_scanner_id', '!=', self.id)])
        if existing_internal_transfer_lines:
            existing_internal_transfer_names = existing_internal_transfer_lines.mapped('internal_transfer_scanner_id'). \
                mapped('name')
            return ', '.join(existing_internal_transfer_names)
        return None

    def ks_get_product_quantity_vals(self, quant_id, multi_location):
        picked_moves = self.ks_get_picked_move_ids(quant_id, multi_location)
        picked_qty = sum(picked_moves.mapped('picked_qty'))
        physical_qty = quant_id.quantity - picked_qty
        vals = {'product_id': quant_id.product_id.id,
                'on_hand_qty': quant_id.quantity,
                'picked_qty': picked_qty,
                'physical_qty': physical_qty if physical_qty > 0 else 0}
        if self.env.context.get('add_quant'):
            vals.update({'quant_id': quant_id.id})
        return vals

    def ks_check_load_product_validations(self, quant_ids, multi_location):
        self.ensure_one()
        if not quant_ids:
            raise UserError(_("You don't have stock on the selected source location."))
        product_ids = quant_ids.mapped('product_id')
        if len(product_ids) > 1:
            confirmation_line_vals = []
            warning = _("You have multiple products at the %s location." % self.location_id.display_name)
            for product in product_ids:
                quant_id = quant_ids.filtered(lambda quant: quant.product_id.id == product.id)
                vals = self.with_context(add_quant=True).ks_get_product_quantity_vals(quant_id, multi_location)
                if vals.get('physical_qty') == 0:
                    warning += _("\nThere is no quantity available of some products. \n\nYou need to connect with your "
                                 "Administrator to perform the physical audit")
                confirmation_line_vals.append((0, 0, vals))
            action = self.env['ir.actions.actions']._for_xml_id('ks_barcode_extension.action_internal_transfer_product_selection')
            action['context'] = {'default_name': warning,
                                 'default_confirmation': True,
                                 'default_product_selection_ids': confirmation_line_vals,
                                 'default_internal_transfer_scanner_id': self.id}
            return action
        else:
            product_quant_ids = quant_ids.filtered(lambda quant: quant.product_id.id in product_ids.ids
                                                   and quant.quantity > 0)
            if len(product_quant_ids) > 1:
                raise UserError(_("You have multiple loose quants for the %s product." % product_ids.display_name))
            picked_moves = self.ks_get_picked_move_ids(product_quant_ids, multi_location)
            picked_qty = sum(picked_moves.mapped('picked_qty'))
            available_qty = product_quant_ids.quantity - picked_qty
            if available_qty <= 0:
                raise UserError(_("Products are not available on %s location. All products must be already picked."
                                  % self.location_id.display_name))
        if len(quant_ids) > 1:
            raise UserError(_("You have multiple loose quants for the %s product." % product_ids.display_name))
        transfer_name = self.ks_check_product_existing_internal_transfer(product_ids)
        if transfer_name:
            raise UserError(_("%s product is already loaded to the %s warehouse transfer"
                              % (product_ids.display_name, transfer_name)))

    def ks_action_load_products(self):
        self.ensure_one()
        if not self.operation_type_id:
            raise UserError(_("You need to scan operation type first."))
        if not self.location_id:
            raise UserError(_("You need to scan source location first."))
        if self.internal_transfer_scanner_lines or self.free_bin or self.product_lines_to_suspense:
            raise UserError(_("Nothing to add in this %s warehouse transfer." % self.name))
        quant_ids = self.location_id.quant_ids.filtered(lambda q: not q.package_id and q.quantity != 0)
        if not quant_ids and self.operation_type_id.internal_transfer_type != 'physical_audit_product':
            raise UserError(_("There is no quantity available at %s location" % self.location_id.display_name))
        res = False
        multi_location = self.location_id.warehouse_id.multi_location_pick
        if self.operation_type_id.internal_transfer_type == 'immediate_loose':
            res = self.ks_add_immediate_loose_product(quant_ids, multi_location)
        elif self.free_negative_bin and self.operation_type_id.internal_transfer_type == 'physical_audit_product':
            vals = []
            quant_ids = quant_ids.filtered(lambda quant: quant.quantity < 0)
            if not quant_ids:
                raise UserError(_("There is no negative quant available at %s location" % self.location_id.display_name))
            for quant_id in quant_ids:
                vals.append((0, 0, self.ks_prepare_vals_for_products(quant_id, multi_location)))
            self.internal_transfer_scanner_lines = vals
            self.readonly_free_negative_bin = True
        else:
            product_ids = quant_ids.mapped('product_id')
            if len(product_ids) > 1:
                product_selection_ids = []
                for quant in quant_ids:
                    vals = self.with_context(add_quant=True).ks_get_product_quantity_vals(quant, multi_location)
                    product_selection_ids.append((0, 0, vals))
                res = self.env['ir.actions.actions']._for_xml_id('ks_barcode_extension.action_internal_transfer_product_selection')
                res['context'] = {'default_product_selection_ids': product_selection_ids,
                                  'default_internal_transfer_scanner_id': self.id,
                                  'default_products_not_to_add': [(6, 0, product_ids.ids)]}
            elif not quant_ids and self.operation_type_id.internal_transfer_type == 'physical_audit_product':
                res = self.env['ir.actions.actions']._for_xml_id(
                    'ks_barcode_extension.action_internal_transfer_product_selection')
                res['context'] = {'default_internal_transfer_scanner_id': self.id,
                                  'default_is_quant_zero':True,
                                  'default_another_product':True}
            else:
                vals = []
                for quant_id in quant_ids:
                    vals.append((0, 0, self.ks_prepare_vals_for_products(quant_id, multi_location)))
                self.internal_transfer_scanner_lines = vals
        return res

    def ks_add_immediate_loose_product(self, quant_ids, multi_location):
        self.ensure_one()
        action = self.ks_check_load_product_validations(quant_ids, multi_location)
        if isinstance(action, dict):
            return action
        vals = []
        for quant_id in quant_ids:
            remaining_qty = 0
            if quant_id.quantity > 0:
                picked_moves = self.ks_get_picked_move_ids(quant_id, multi_location)
                picked_qty = sum(picked_moves.mapped('picked_qty'))
                remaining_qty = quant_id.quantity - picked_qty
            if remaining_qty <= 0:
                continue
            vals.append((0, 0, {'product_id': quant_id.product_id.id,
                                'physically_available_qty': remaining_qty,
                                'scanned': True}))
        if not vals:
            raise UserError("There is nothing to add.")
        self.internal_transfer_scanner_lines = vals

    def ks_get_picked_move_ids(self, quant_id, multi_location):
        if multi_location:
            move_ids = self.env['stock.move'].search([('pick_from', '=', quant_id.location_id.id),
                                                      ('product_id', '=', quant_id.product_id.id),
                                                      ('state', 'not in', ['cancel', 'done']),
                                                      ('picked_qty', '>', 0)])
        else:
            move_ids = self.env['stock.move'].search([('location_id', '=', quant_id.location_id.id),
                                                      ('product_id', '=', quant_id.product_id.id),
                                                      ('state', 'not in', ['cancel', 'done']),
                                                      ('picked_qty', '>', 0)])
        return move_ids

    def ks_prepare_vals_for_products(self, quant_id, multi_location=False):
        self.ensure_one()
        vals = quant_id.ks_get_product_line_vals()
        move_ids = self.ks_get_picked_move_ids(quant_id, multi_location)
        if move_ids:
            picked_vals, picked_qty = self.ks_prepare_reserved_products_vals(move_ids)
            available_qty = vals['on_hand_qty'] - picked_qty
            vals.update({'physically_available_qty': available_qty if available_qty > 0 else 0,
                         'picked_qty': picked_qty,
                         'available_qty': available_qty,
                         'package_reserved_move_ids': picked_vals})
        return vals

    def ks_prepare_reserved_products_vals(self, move_ids):
        self.ensure_one()
        vals, total_picked_qty = [], 0
        for move in move_ids:
            vals.append((0, 0, {'picked_qty': move.picked_qty,
                                'move_id': move.id}))
            total_picked_qty += move.picked_qty
        return vals, total_picked_qty

    def action_view_adjusted_quants(self):
        self.ensure_one()
        action = self.env['ir.actions.actions']._for_xml_id('ks_barcode_extension.stock_quant_warehouse_transfer_action')
        quant_ids = self.internal_transfer_scanner_lines.mapped('quant_id')
        action['domain'] = [('id', 'in', quant_ids.ids)]
        return action

    def ks_action_assign_to_me(self):
        self.ensure_one()
        if self.state == 'draft':
            self.with_context(assign=True).check_location_validation_warnings()
            self.check_diff_warehouse_warning()
        if self.assigned_worker_id.id == self.env.uid:
            raise UserError(_("You are already assigned to this warehouse transfer."))
        self.ks_check_user_limit()
        message_body = _("Assign User -> <b> %s </b>" % self.env.user.name.upper())
        self.message_post(body=message_body, partner_ids=self.env.user.partner_id.ids)
        if self.state != 'assigned':
            self.message_post(body=self._create_message_to_post('assigned'))
            self.write({'assigned_worker_id': self.env.uid,
                        'state': 'assigned'})
        else:
            self.assigned_worker_id = self.env.uid

    def ks_check_user_limit(self):
        if self.env.user.has_group('ks_barcode_extension.warehouse_transfer_manager'):
            return
        transfer_limit = self.env['ir.config_parameter'].sudo().get_param("ks_barcode_extension.transfer_limit")
        if transfer_limit:
            current_assigned_records = self.search([('state', '=', 'assigned'),
                                                    ('assigned_worker_id', '=', self.env.user.id)])
            if int(transfer_limit) <= int(len(current_assigned_records)):
                raise UserError(_(f"There are already {len(current_assigned_records)} Warehouse Transfer records assigned to you. Please move or cancel them before proceeding"))


    def ks_unpack_transfer_to_suspense(self):
        for record in self:
            if self.available_product_count > 0 and self.location_dest_id.quant_ids:
                package_ids = self.internal_transfer_scanner_lines.mapped('package_id')
                product_ids = package_ids.mapped('quant_ids').mapped('product_id')
                unmatched_prod_quants = self.location_dest_id.quant_ids. \
                    filtered(lambda quant: quant.product_id.id not in product_ids.ids)
                if unmatched_prod_quants:
                    suspense_transfer_id = record.with_context(suspense=True).ks_create_internal_transfer('immediate')
                    vals = record.location_dest_id.quant_ids.ks_unpack_move_line_vals(suspense_transfer_id)
                    self.env['stock.move.line'].create(vals)

    def ks_transfer_bin_stock_to_suspense(self):
        self.ensure_one()
        transfer_id = self.with_context(suspense=True).ks_create_internal_transfer('immediate')
        suspense_lines_vals = self.product_lines_to_suspense.ks_prepare_move_line_vals(transfer_id)
        self.env['stock.move.line'].create(suspense_lines_vals)

    @api.model
    def ks_validate_transfer_cron(self):
        _logger.info("====>>>> Warehouse Transfer Validate Cron Executing.")
        start_time = time.time()
        execution_limit = self.env['ir.config_parameter'].get_param('ks_barcode_extension.validate_cron_execution_time')
        for rec in self.search([('validate_by_cron', '=', True), ('state', 'not in', ['moved', 'cancel'])], limit=5):
            current_time = time.time()
            if (current_time - start_time) >= ((float(execution_limit) * 60) if float(execution_limit) else 600):
                _logger.info("====>>>> Stopping Warehouse Transfer Validate Cron Execution because of time limit")
                break
            try:
                _logger.info(f"====>>>> Validated Transfer with ID {rec.id}")
                rec._ks_action_validate()
                _logger.info(f"====>>>> Warehouse Transfer with ID {rec.id} Validated")
            except Exception as error:
                _logger.exception(f"Failed to validate warehouse transfer with id {rec.id} due to {error}")
        _logger.info("=====>>>> Warehouse Transfer validate Cron Execution Completed")

    def ks_update_pack_source_location(self):
        for rec in self:
            if rec.internal_transfer_scanner_lines.mapped('package_id') and not rec.internal_transfer_scanner_lines.mapped('package_source_location_id'):
                for line in rec.internal_transfer_scanner_lines:
                    ml = rec.destination_internal_transfer_ids.move_line_ids.filtered(lambda pack: pack.package_id == line.package_id)
                    if ml:
                        line.package_source_location_id = ml.location_id.id
