# -*- coding: utf-8 -*-
import qrcode
import base64
from io import BytesIO
from odoo import models, fields, api


class StockPickingType(models.Model):
    _inherit = 'stock.picking.type'

    operation_type_prefix = 'OT-'

    internal_transfer_type = fields.Selection([('immediate_transfer', 'Immediate Transfer'),
                                               ('whole_stock', 'Whole Stock'),
                                               ('physical_audit', 'Physical Audit Packages'),
                                               ('immediate_unpack', 'Immediate Unpacking'),
                                               ('physical_audit_product', 'Physical Audit Products'),
                                               ('immediate_loose', 'Immediate Loose')], 'Internal Transfer Type')

    def ks_action_set_barcode(self):
        for operation_type in self:
            if operation_type.barcode:
                if not operation_type.barcode.startswith(self.operation_type_prefix):
                    operation_type.barcode = self.operation_type_prefix + operation_type.barcode

    @api.model
    def create(self, vals):
        if vals.get('barcode'):
            if not vals['barcode'].startswith(self.operation_type_prefix):
                vals['barcode'] = self.operation_type_prefix + vals['barcode']
        return super(StockPickingType, self).create(vals)

    def write(self, vals):
        if vals.get('barcode'):
            if not vals['barcode'].startswith(self.operation_type_prefix):
                vals['barcode'] = self.operation_type_prefix + vals['barcode']
        return super(StockPickingType, self).write(vals)

    @api.model
    def name_search(self, name='', args=None, operator='ilike', limit=100):
        if self.env.context.get('warehouse_transfer'):
            args = self.ks_get_grouped_operation_types(args)
        return super(StockPickingType, self).name_search(name, args, operator, limit)

    def ks_get_grouped_operation_types(self, domain):
        operation_type_domain = [['warehouse_id', '=', self.env.user.property_warehouse_id.id]]
        if domain:
            domain.extend(operation_type_domain)
        else:
            domain = operation_type_domain
        return domain

    @api.model
    def search_read(self, domain=None, fields=None, offset=0, limit=None, order=None, **read_kwargs):
        if self.env.context.get('warehouse_transfer'):
            domain = self.ks_get_grouped_operation_types(domain)
        return super(StockPickingType, self).search_read(domain, fields, offset, limit, order, **read_kwargs)

    def generate_qr_code(self):
        for rec in self:
            qr = qrcode.QRCode(
                version=1,
                error_correction=qrcode.constants.ERROR_CORRECT_L,
                box_size=3,
                border=4,
            )
            qr.add_data(rec.barcode)
            qr.make(fit=True)
            img = qr.make_image()
            temp = BytesIO()
            img.save(temp, format="PNG")
            qr_image = base64.b64encode(temp.getvalue())
            return qr_image