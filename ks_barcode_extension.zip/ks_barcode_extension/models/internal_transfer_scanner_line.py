# -*- coding: utf-8 -*-

from collections import defaultdict

from odoo import models, fields, _, api, SUPERUSER_ID
from odoo.exceptions import UserError


class InternalTransferScannerLine(models.Model):
    _name = 'internal.transfer.scanner.line'
    _description = 'Internal Transfer Scanner Line'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    internal_transfer_scanner_id = fields.Many2one('internal.transfer.scanner', 'Internal Transfer Scanner')
    package_id = fields.Many2one('stock.quant.package', 'Package')
    blp = fields.Char('Box License Plate', related='package_id.x_blp')
    gtin_qty_code = fields.Char('GTIN and Quantity Code', related='package_id.x_gtin_qty_code')
    scanned = fields.Boolean('Scanned', default=False)
    location_id = fields.Many2one('stock.location', "Package's Current Location", related='package_id.location_id')
    company_id = fields.Many2one('res.company', 'Company', default=lambda self: self.env.company, required=True)
    physically_available = fields.Boolean('Physically Available', default=False, tracking=True, copy=False)
    product_id = fields.Many2one('product.product', string='Product')
    quantity = fields.Integer(string='Quantity')
    package_reserved_move_ids = fields.One2many('package.reserve.stock.move', 'internal_transfer_scanner_line_id',
                                                string='Reserved Move')
    state = fields.Selection(related='internal_transfer_scanner_id.state', store=True)
    barcode = fields.Char('Barcode', related='product_id.barcode', store=True)
    on_hand_qty = fields.Float('On-Hand Qty')
    physically_available_qty = fields.Float('Physical Qty', tracking=True, copy=False)
    picked_qty = fields.Float('Picked Qty')
    available_qty = fields.Float('Available Qty')
    operation_type = fields.Selection(related='internal_transfer_scanner_id.operation_type')
    quant_id = fields.Many2one('stock.quant', 'Quant')
    inventory_adjusted = fields.Boolean('Inventory Adjusted')
    location_src_id = fields.Many2one('stock.location', related='internal_transfer_scanner_id.location_id',
                                      string='Transfer Source Location')
    location_dest_id = fields.Many2one('stock.location', related='internal_transfer_scanner_id.location_dest_id')
    need_update = fields.Boolean('Need to update line')
    new_on_hand_qty = fields.Float("New On-Hand Qty", compute="_ks_compute_new_on_hand_qty")
    readonly_free_negative_bin = fields.Boolean(related='internal_transfer_scanner_id.readonly_free_negative_bin')
    product_ids = fields.Many2many('product.product','scanner_line_id','product_id', string='Package SKUs', compute='ks_compute_pack_sku')
    package_source_location_id = fields.Many2one('stock.location', string='Package Source Location', compute='ks_store_package_source_location', store=True)

    @api.depends('package_id')
    def ks_store_package_source_location(self):
        for rec in self:
            if rec.state not in ('moved', 'cancel') and rec.operation_type not in ('immediate_loose', 'physical_audit_product'):
                rec.package_source_location_id = rec.package_id.location_id.id
            else:
                rec.package_source_location_id = rec.package_source_location_id if rec.package_source_location_id else False

    def write(self, vals):
        if 'physically_available_qty' in vals:
            physical_qty_limit = self.env['ir.config_parameter'].sudo().get_param('ks_barcode_extension.physical_available_limit')
            if physical_qty_limit and float(vals.get('physically_available_qty')) > float(physical_qty_limit) and float(vals.get('physically_available_qty')) > float(self.physically_available_qty):
                raise UserError(f'You are not allowed to put the Physical Quantity more than {physical_qty_limit}. Please Contact Administrator.')
        return super(InternalTransferScannerLine, self).write(vals)

    def ks_compute_pack_sku(self):
        for rec in self:
            if rec.package_id:
                rec.product_ids = rec.package_id.quant_ids.mapped('product_id').ids
            else:
                rec.product_ids = False

    @api.depends('picked_qty', 'physically_available_qty')
    def _ks_compute_new_on_hand_qty(self):
        for line in self:
            line.new_on_hand_qty = line.picked_qty + line.physically_available_qty

    @api.onchange('physically_available_qty')
    def _onchange_physically_availbale_qty(self):
        for record in self:
            if record.physically_available_qty < 0:
                raise UserError(_("The physical quantity must be positive."))

    def prepare_product_qty_for_move(self):
        """
        This method can prepare the dictionary to create the stock moves for the planned transfer.
        return: dictionary of the values.
        """
        products_with_qty = defaultdict(list)
        for scanner_line in self:
            for quant in scanner_line.package_id.quant_ids:
                product_id = quant.product_id.id
                if product_id in products_with_qty.keys():
                    key_found = False
                    for val_list in products_with_qty[product_id]:
                        if val_list['location_id'] == quant.location_id.id:
                            val_list['quantity'] += quant.quantity
                            if scanner_line.package_id.id not in val_list['package_ids']:
                                val_list['package_ids'].append(scanner_line.package_id.id)
                            key_found = True
                            break
                    if not key_found:
                        products_with_qty[product_id].append({'quantity': quant.quantity,
                                                              'package_ids': [scanner_line.package_id.id],
                                                              'location_id': quant.location_id.id,
                                                              'product_id': quant.product_id.id})
                else:
                    products_with_qty[quant.product_id.id] = [{'quantity': quant.quantity,
                                                               'package_ids': [scanner_line.package_id.id],
                                                               'product_id': quant.product_id.id,
                                                               'location_id': quant.location_id.id}]
        return products_with_qty

    def unlink(self):
        """
        If the line is not done then remove the scanned line else raise warning.
        return: response of the super method.
        """
        warning = ''
        done_lines = self.filtered(lambda line: line.state == 'moved')
        if done_lines:
            warning += 'The following packages is already transferred.\n'
            index = 1
            for dl in done_lines:
                warning += _("%s. %s - %s.\n" % (index, dl.package_id.name, dl.package_id.x_blp))
                index += 1
        if warning:
            raise UserError(warning)
        return super(InternalTransferScannerLine, self).unlink()

    def prepare_package_levels_vals(self, internal_transfer_id):
        """
        prepare the values for the package levels to create for the immediate transfer.
        internal_transfer_id: package level linked with which transfer.
        return: dict of the values.
        """
        self.ensure_one()
        vals = {
            'location_dest_id': internal_transfer_id.location_dest_id.id,
            'location_id': self.package_id.location_id.id,
            'picking_id': internal_transfer_id.id,
            'company_id': self.env.company.id,
            'package_id': self.package_id.id,
            'is_done': True
        }
        if self.env.context.get('location_id'):
            vals['location_id'] = self.env.context.get('location_id')
        if self.env.context.get('not_done'):
            vals['is_done'] = False
        return vals

    def action_remove_reserved_move_line(self):
        reserved_packages_lines = self.mapped('package_reserved_move_ids')
        if reserved_packages_lines:
            for reserved_pack_line in reserved_packages_lines:
                reserved_pack_line.move_line_id.unlink()

    def action_reserve_lines(self):
        reserved_packages_lines = self.mapped('package_reserved_move_ids')
        if reserved_packages_lines:
            for line in reserved_packages_lines:
                if line.picked:
                    line.move_id.ks_reserve_desired_packages(line.package_id.ids)
                    line.move_id._recompute_state()
                    package_level_id = line.move_id.picking_id.package_level_ids_details.\
                        filtered(lambda pl: pl.package_id.id == line.package_id.id)
                    if not package_level_id:
                        picking_id = line.move_id.picking_id
                        vals = line.internal_transfer_scanner_line_id.with_context(not_done=True).prepare_package_levels_vals(picking_id)
                        package_level_id = self.env['stock.package_level'].create(vals)
                    move_lines_to_pack = line.move_id.move_line_ids.filtered(
                        lambda ml: ml.package_id.id == package_level_id.package_id.id and not ml.result_package_id)
                    move_lines_in_package_level = move_lines_to_pack.filtered(lambda ml: ml.move_id.package_level_id)
                    for move_line in move_lines_in_package_level:
                        move_line.write({
                            'result_package_id': package_level_id.package_id.id,
                            'package_level_id': move_line.move_id.package_level_id.id,
                        })
                    if line.done:
                        package_level_id.is_done = True

    def ks_prepare_immediate_unpack_move_line_vals(self, internal_transfer_id):
        vals = []
        for line in self:
            for quant in line.package_id.quant_ids:
                vals.append({
                    'package_id': line.package_id.id,
                    'company_id': line.package_id.company_id.id,
                    'product_id': quant.product_id.id,
                    'product_uom_id': quant.product_uom_id.id,
                    'location_id': quant.location_id.id,
                    'location_dest_id': internal_transfer_id.location_dest_id.id,
                    'x_studio_future_lot': quant.x_future_lot,
                    'picking_id': internal_transfer_id.id,
                    'qty_done': quant.quantity,
                })
        return vals

    def prepare_internal_transfer_move_values(self, product_id, quantity, location_id, transfer_id):
        product = self.env['product.product'].browse(product_id)
        return {
            'name': product.display_name,
            'company_id': transfer_id.company_id.id,
            'product_id': product.id,
            'product_uom_qty': quantity,
            'product_uom': product.uom_id.id,
            'location_id': location_id,
            'location_dest_id': transfer_id.location_dest_id.id,
            'picking_id': transfer_id.id,
            'picking_type_id': transfer_id.picking_type_id.id,
            'origin': transfer_id.origin
        }

    def ks_prepare_immediate_loose_move_line_vals(self, transfer_id):
        vals = []
        for line in self:
            if line.operation_type == 'physical_audit_product':
                if self.env.context.get('suspense'):
                    quantity = line.on_hand_qty - line.new_on_hand_qty
            elif line.operation_type == 'immediate_loose':
                quantity = line.physically_available_qty
            else:
                quantity = line.quantity
            vals.append({
                'company_id': line.company_id.id,
                'product_id': line.product_id.id,
                'product_uom_id': line.product_id.uom_id.id,
                'location_id': transfer_id.location_id.id,
                'location_dest_id': transfer_id.location_dest_id.id,
                'qty_done': quantity,
                'picking_id': transfer_id.id
            })
        return vals

    def prepare_and_reserve_packages(self, transfer_id):
        product_qty = self.prepare_product_qty_for_move()
        for product_id, values in product_qty.items():
            for val in values:
                move_vals = self.prepare_internal_transfer_move_values(product_id, val['quantity'],
                                                                       val['location_id'], transfer_id)
                move_id = self.env['stock.move'].create(move_vals)
                move_id.ks_reserve_desired_packages(val['package_ids'])
                move_id._action_confirm()
                move_id._set_quantities_to_reservation()

    def ks_create_immediate_unpack_move_lines(self, transfer_id):
        self.action_remove_reserved_move_line()
        if transfer_id.immediate_transfer:
            vals = self.ks_prepare_immediate_unpack_move_line_vals(transfer_id)
            self.env['stock.move.line'].create(vals)
        else:
            self.prepare_and_reserve_packages(transfer_id)

    def ks_create_loose_move_lines(self, transfer_id):
        vals = self.ks_prepare_immediate_loose_move_line_vals(transfer_id)
        self.env['stock.move.line'].create(vals)

    def ks_transfer_packages(self, transfer_id):
        self.action_remove_reserved_move_line()
        if transfer_id.immediate_transfer:
            for line in self:
                vals = line.prepare_package_levels_vals(transfer_id)
                self.env['stock.package_level'].create(vals)
        else:
            self.prepare_and_reserve_packages(transfer_id)

    def ks_create_physical_audit_stock_move_lines(self, transfer_id, transfer_type):
        destination_location_lines = self.filtered(lambda line: line.physically_available)
        suspense_location_lines = self - destination_location_lines
        if destination_location_lines:
            destination_location_lines.ks_transfer_packages(transfer_id)
        if suspense_location_lines:
            suspense_transfer_id = self.internal_transfer_scanner_id.with_context(suspense=True).\
                ks_create_internal_transfer(transfer_type)
            suspense_location_lines.ks_transfer_packages(suspense_transfer_id)
            if not suspense_transfer_id.move_line_ids:
                suspense_transfer_id.action_cancel()
                suspense_transfer_id.unlink()
        if not transfer_id.move_line_ids:
            transfer_id.action_cancel()
            transfer_id.unlink()

    def ks_action_reserve_unpack_lines(self):
        reserved_packages_lines = self.mapped('package_reserved_move_ids')
        if reserved_packages_lines:
            for line in reserved_packages_lines:
                line.move_id._action_assign()

    def ks_action_adjust_inventory(self):
        for line in self:
            if not line.quant_id:
                quant_id = self.env['stock.quant'].search([('product_id', '=', line.product_id.id),
                                                           ('location_id', '=', line.location_src_id.id),
                                                           ('package_id', '=', None),
                                                           ('lot_id', '=', None)], limit=1, order='id desc')
                if not quant_id:
                    quant_id = self.env['stock.quant'].create(self.ks_prepare_quant_vals())
                line.quant_id = quant_id.id
            suspense_qty = 0
            if line.on_hand_qty > line.new_on_hand_qty:
                suspense_qty = line.on_hand_qty - line.new_on_hand_qty
            quantity_to_update = line.new_on_hand_qty + suspense_qty
            line.quant_id.inventory_quantity = quantity_to_update
            context = dict(self.env.context)
            if line.quant_id.inventory_quantity == line.quant_id.quantity:
                context.pop('from_warehouse_transfer', None)
                self.env.context = context
            line.quant_id.with_user(SUPERUSER_ID)._apply_inventory()
            line.quant_id.inventory_quantity_set = False
            if line.quant_id.quantity == quantity_to_update:
                line.inventory_adjusted = True
        internal_transfer_id = self.mapped('internal_transfer_scanner_id')
        internal_transfer_id.inventory_adjusted = any([line.inventory_adjusted for line in self])

    def ks_prepare_quant_vals(self):
        self.ensure_one()
        return {
            'product_id': self.product_id.id,
            'location_id': self.location_src_id.id
        }

    def ks_transfer_to_suspense(self):
        lines_transfer_to_suspense = self.filtered(lambda line: line.on_hand_qty > line.new_on_hand_qty)
        if lines_transfer_to_suspense:
            internal_transfer_id = self.mapped('internal_transfer_scanner_id')
            suspense_transfer_id = internal_transfer_id.with_context(suspense=True). \
                ks_create_internal_transfer('immediate')
            lines_transfer_to_suspense.with_context(suspense=True).ks_create_loose_move_lines(suspense_transfer_id)

    def ks_transfer_loose_products(self, transfer_id):
        lines_to_transfer = self.filtered(lambda pl: pl.physically_available_qty > 0)
        if lines_to_transfer:
            if transfer_id.immediate_transfer:
                lines_to_transfer.ks_create_loose_move_lines(transfer_id)
            else:
                for line in lines_to_transfer:
                    vals = line.prepare_internal_transfer_move_values(line.product_id.id, line.physically_available_qty,
                                                                      transfer_id.location_id.id, transfer_id)

                    move_id = self.env['stock.move'].create(vals)
                    available_qty = move_id._get_available_quantity(move_id.location_id, strict=True)
                    if available_qty > 0:
                        need = min(move_id.product_uom_qty, available_qty)
                        move_id._update_reserved_quantity(need, available_qty, move_id.location_id, strict=True)
                    done_qty = move_id.product_uom_qty
                    if move_id.move_line_ids:
                        if len(move_id.move_line_ids) == 1:
                            move_id.move_line_ids.qty_done = done_qty
                        else:
                            raise UserError(_("There are multiple stock move lines for a loose move. Need to check the"
                                              " quants to find the issue."))
                    else:
                        move_id.quantity_done = done_qty
        else:
            transfer_id.action_cancel()
            transfer_id.unlink()