# -*- coding: utf-8 -*-

from odoo import models, fields


class StockPicking(models.Model):
    _inherit = 'stock.picking'

    internal_transfer_scanner_id = fields.Many2one('internal.transfer.scanner', 'Internal Transfer Scanner')

    def prepare_scanned_package_level_vals(self, package_id, move_id):
        """
        package_id: package.
        move_id: takes the location and location destination of the move.
        Create the package level vals.
        return: dict of vals
        """
        self.ensure_one()
        return {'package_id': package_id,
                'picking_id': self.id,
                'location_id': move_id.location_id.id,
                'location_dest_id': move_id.location_dest_id.id,
                'company_id': self.company_id.id,
                'picked': True}

    def reserve_desired_packages_to_move(self, package_ids, move_id):
        """
        package_ids: desired packages
        move_id: desired move
        This method is used to reserve the desired packages to the desired move.
        If the package level is not present to for the package then create a new one and update the move pacakge level
        with that package level and call the action assign method to reserve that package.
        return: None
        """
        self.ensure_one()
        for package_id in package_ids:
            existing_package_level = self.package_level_ids_details.filtered(lambda pl: pl.package_id.id == package_id)
            if not existing_package_level:
                vals = self.prepare_scanned_package_level_vals(package_id, move_id)
                package_level_id = self.env['stock.package_level'].create(vals)
            else:
                package_level_id = existing_package_level
            move_id.package_level_id = package_level_id.id
            if move_id.state == 'draft':
                move_id._action_confirm()
            elif move_id.state in ['confirmed', 'waiting', 'partially_available']:
                move_id._action_assign()
            if move_id.reserved_availability == move_id.product_uom_qty:
                move_id.checked = True

    def update_done_qty_internal_transfer(self):
        """
        This method can update the done quantity of the stock move line and stock move as well as done the package
        level.
        """
        self.ensure_one()
        if self.package_level_ids_details:
            for pack_level in self.package_level_ids_details:
                if pack_level.state == 'assigned':
                    pack_level.is_done = True

    # def button_validate(self):
    #     """
    #     After the validation of the picking done the internal transfer scanner lines.
    #     """
    #     res = super(StockPicking, self).button_validate()
    #     for picking in self:
    #         if picking.internal_transfer_scanner_id:
    #             package_ids = picking.package_level_ids_details.mapped('package_id').ids
    #             if package_ids:
    #                 lines_to_done = self.env['internal.transfer.scanner.line']
    #                 scanned_lines = picking.internal_transfer_scanner_id.internal_transfer_scanner_lines
    #                 for package_id in package_ids:
    #                     lines_to_done |= scanned_lines.filtered(lambda line: line.package_id.id == package_id)
    #                 lines_to_reserve = lines_to_done.filtered(lambda line: line.reserved_move_ids)
    #                 lines_to_reserve.action_reserve_lines()
    #                 if lines_to_done:
    #                     for ld in lines_to_done:
    #                         ld.is_done = True
    #     return res
