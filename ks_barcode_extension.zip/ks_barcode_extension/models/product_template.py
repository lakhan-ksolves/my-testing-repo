# -*- coding: utf-8 -*-

from odoo import models, api


class ProductTemplate(models.Model):
    _inherit = 'product.template'

    product_prefix = 'PROD-'

    def ks_action_set_barcode(self):
        for product in self:
            if product.barcode:
                if not product.barcode.startswith(self.product_prefix):
                    product.barcode = self.product_prefix + product.barcode
            else:
                if product.default_code:
                    product.barcode = self.product_prefix + product.default_code

    @api.model
    def create(self, vals):
        if vals.get('barcode'):
            if not vals['barcode'].startswith(self.product_prefix):
                vals['barcode'] = self.product_prefix + vals['barcode']
        else:
            if vals.get('default_code'):
                vals['barcode'] = self.product_prefix + vals['default_code']
        return super(ProductTemplate, self).create(vals)

    def write(self, vals):
        if vals.get('barcode'):
            if not vals['barcode'].startswith(self.product_prefix):
                vals['barcode'] = self.product_prefix + vals['barcode']
        else:
            if vals.get('default_code'):
                vals['barcode'] = self.product_prefix + vals['default_code']
        return super(ProductTemplate, self).write(vals)
