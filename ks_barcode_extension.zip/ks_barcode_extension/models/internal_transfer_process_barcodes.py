# -*- coding: utf-8 -*-

from odoo import models, fields
import qrcode
import base64
from io import BytesIO

class InternalTransferProcessBarcode(models.Model):
    _name = 'internal.transfer.process.barcode'
    _description = 'Internal Transfer Process Barcode'

    action_cancel = fields.Char('Action Cancel Barcode', required=True)
    action_validate = fields.Char('Action Validate', required=True)
    action_assign_to_me = fields.Char('Action Assign to Me', required=True)
    action_load_product = fields.Char('Action Load Product', required=True)
    action_load_boxes = fields.Char('Action Load Source Boxes',required=True)


    def generate_action_cancel_qr_code(self):
        for rec in self:
            image = self.generate_qr(rec.action_cancel)
            return image

    def generate_action_validate_qr_code(self):
        for rec in self:
            image = self.generate_qr(rec.action_validate)
            return image

    def generate_action_assign_to_me_qr_code(self):
        for rec in self:
            image = self.generate_qr(rec.action_assign_to_me)
            return image

    def generate_action_load_product_qr_code(self):
        for rec in self:
            image = self.generate_qr(rec.action_load_product)
            return image

    def generate_action_load_boxes_qr_code(self):
        for rec in self:
            image = self.generate_qr(rec.action_load_boxes)
            return image


    def generate_qr(self, field):
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_L,
            box_size=3,
            border=4,
        )
        qr.add_data(field)
        qr.make(fit=True)
        img = qr.make_image()
        temp = BytesIO()
        img.save(temp, format="PNG")
        qr_image = base64.b64encode(temp.getvalue())
        return qr_image
