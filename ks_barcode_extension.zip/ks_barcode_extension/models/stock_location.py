# -*- coding: utf-8 -*-

from odoo import models, fields, api, _
import logging
import qrcode
import base64
from io import BytesIO

_logger = logging.getLogger(__name__)


class StockLocation(models.Model):
    _inherit = 'stock.location'

    location_prefix = 'LOC-'

    package_limit = fields.Integer('Package Limit')
    is_open_location = fields.Boolean('Is Open Location?')
    product_limit = fields.Integer('Product Limit')
    restrict_limit = fields.Boolean('Restrict Limit')
    open_location_type = fields.Selection([('bay', 'Bay'),
                                           ('bin', 'Bin')], string='Open Type')
    suspense_location = fields.Boolean('Suspense Location')
    is_empty_location = fields.Boolean(compute='ks_check_is_empty_location', search='_search_is_empty_location')
    restrict_multi_sku = fields.Boolean(string='Restrict Multiple SKUs')

    @api.model
    def name_search(self, name='', args=None, operator='ilike', limit=100):
        domain = self.ks_get_internal_transfer_location_domain()
        if domain:
            if args:
                args.extend(domain)
            else:
                args = domain
        return super(StockLocation, self).name_search(name, args, operator, limit)

    def ks_get_internal_transfer_location_domain(self):
        operation_type = self.env.context.get('operation_type')
        source = self.env.context.get('source')
        destination = self.env.context.get('destination')
        if operation_type:
            domain = []
            if operation_type in ['immediate_transfer', 'whole_stock', 'physical_audit']:
                if source and operation_type == 'immediate_transfer':
                    domain = []
                elif source and operation_type in ['whole_stock', 'physical_audit']:
                    query = "select distinct(location_id) from stock_quant where package_id is not null;"
                    try:
                        self.env.cr.execute(query)
                        res = self.env.cr.fetchall()
                    except Exception as Error:
                        _logger.info(Error)
                        return domain
                    location_ids = [location_id[0] for location_id in res]
                    domain = [['is_open_location', '!=', True], ['id', 'in', location_ids]]
                else:
                    domain = [['is_open_location', '!=', True]]
            elif operation_type == 'immediate_unpack':
                if destination:
                    domain = [['is_open_location', '=', True], ['open_location_type', '=', 'bin']]
            elif operation_type == 'physical_audit_product':
                domain = [['is_open_location', '=', True], ['open_location_type', '=', 'bin']]
            elif operation_type == 'immediate_loose':
                domain = [['is_open_location', '=', True], ['open_location_type', '=', 'bin']]
                if source:
                    query = "select distinct(location_id) from stock_quant where package_id is null and lot_id is null;"
                    try:
                        self.env.cr.execute(query)
                        res = self.env.cr.fetchall()
                    except Exception as Error:
                        _logger.info(Error)
                        return domain
                    location_ids = [location_id[0] for location_id in res]
                    domain.append(['id', 'in', location_ids])
            return domain
        return []

    @api.model
    def search_read(self, domain=None, fields=None, offset=0, limit=None, order=None, **read_kwargs):
        location_domain = self.ks_get_internal_transfer_location_domain()
        if location_domain:
            if domain:
                domain.extend(location_domain)
            else:
                domain = location_domain
        return super(StockLocation, self).search_read(domain, fields, offset, limit, order, **read_kwargs)

    def ks_set_child_open_locations(self):
        for location in self:
            for child_location in location.child_internal_location_ids:
                child_location.is_open_location = True
            location.is_open_location = True

    def ks_set_restriction_limit(self):
        locations = self.env['stock.location'].search([('usage', '=', 'internal'), ('package_limit', '!=', None)])
        for location in locations:
            location.restrict_limit = True

    def ks_check_is_empty_location(self):
        self.ensure_one()
        if self.env.context.get('packages'):
            quant_ids = self.quant_ids.filtered(lambda quant: quant.package_id and not quant.lot_id)
        else:
            quant_ids = self.quant_ids
        if not bool(quant_ids) and not bool(self.child_internal_location_ids.quant_ids):
            self.is_empty_location = True
        else:
            self.is_empty_location = False
        return not bool(quant_ids)

    def _search_is_empty_location(self, operator, value):
        locations = self.env['stock.location'].search([]).filtered(lambda l: not bool(l.quant_ids) and not bool(l.child_internal_location_ids.quant_ids)).ids
        return [('id', 'in', locations)]

    def ks_remove_location_prefix(self):
        locations = self.env['stock.location'].search([('usage', '=', 'internal'), ('barcode', '!=', None)])
        for location in locations:
            if location.barcode.startswith('LOC-'):
                barcode = location.barcode.replace('LOC-', '')
                location.write({'barcode': barcode})

    def ks_set_as_bin_bay(self, loc_type):
        for location in self:
            location.write({'is_open_location': True,
                            'open_location_type': loc_type})

    def generate_qr_code(self):
        for rec in self:
            qr = qrcode.QRCode(
                version=1,
                error_correction=qrcode.constants.ERROR_CORRECT_L,
                box_size=3,
                border=4,
            )
            qr.add_data(rec.barcode)
            qr.make(fit=True)
            img = qr.make_image()
            temp = BytesIO()
            img.save(temp, format="PNG")
            qr_image = base64.b64encode(temp.getvalue())
            return qr_image