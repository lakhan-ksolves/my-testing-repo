# -*- coding: utf-8 -*-

from odoo import models


class StockMove(models.Model):
    _inherit = 'stock.move'

    def ks_reserve_desired_packages(self, packages_list):
        self.ensure_one()
        package_ids = self.env['stock.quant.package'].browse(packages_list)
        need = self.product_uom_qty
        for package_id in package_ids:
            available_quantity = self._get_available_quantity(self.location_id, package_id=package_id)
            if available_quantity <= 0:
                continue
            taken_quantity = self._update_reserved_quantity(need, available_quantity, self.location_id,
                                                            package_id=package_id, strict=False)
            need -= taken_quantity
