# -*- coding: utf-8 -*-

from odoo import models, fields


class ProductLineSuspense(models.Model):
    _name = 'product.line.suspense'
    _description = 'Product Line Suspense'

    internal_transfer_scanner_id = fields.Many2one('internal.transfer.scanner')
    product_id = fields.Many2one('product.product', 'Product')
    quantity = fields.Float('Quantity')

    def ks_prepare_move_line_vals(self, transfer_id):
        vals = []
        for line in self:
            vals.append({
                'company_id': line.internal_transfer_scanner_id.company_id.id,
                'product_id': line.product_id.id,
                'product_uom_id': line.product_id.uom_id.id,
                'location_id': transfer_id.location_id.id,
                'location_dest_id': transfer_id.location_dest_id.id,
                'qty_done': line.quantity,
                'picking_id': transfer_id.id
            })
        return vals
