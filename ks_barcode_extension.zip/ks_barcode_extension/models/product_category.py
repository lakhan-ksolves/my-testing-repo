# -*- coding: utf-8 -*-

from odoo import models, fields


class ProductCategory(models.Model):
    _inherit = 'product.category'

    finished_category = fields.Boolean('Finished Category', copy=False)


class ProductTemplate(models.Model):
    _inherit = 'product.template'

    is_solo_sku = fields.Boolean(string='WT Solo Restriction')
