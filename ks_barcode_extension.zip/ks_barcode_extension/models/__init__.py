# -*- coding: utf-8 -*-

from . import internal_transfer_scanner
from . import stock_quant_package
from . import res_config_settings
from . import stock_picking
from . import internal_transfer_process_barcodes
from . import stock_location
from . import stock_picking_type
# from . import product_template
from . import internal_transfer_scanner_line
from . import package_reserve_stock_move
from . import stock_move
from . import stock_quant
from . import stock_warehouse
from . import product_line_suspense
from . import product_category
