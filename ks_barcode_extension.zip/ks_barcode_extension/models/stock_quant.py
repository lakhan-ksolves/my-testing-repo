# -*- coding: utf-8 -*-

from odoo import models


class StockQuant(models.Model):
    _inherit = 'stock.quant'

    def ks_get_product_line_vals(self):
        self.ensure_one()
        return {'product_id': self.product_id.id,
                'quant_id': self.id,
                'on_hand_qty': self.quantity,
                'physically_available_qty': self.quantity if self.quantity > 0 else 0,
                'picked_qty': 0,
                'available_qty': self.quantity,
                'scanned': True}

    def ks_unpack_move_line_vals(self, transfer_id):
        vals = []
        for quant in self:
            vals.append({
                'company_id': quant.company_id.id,
                'product_id': quant.product_id.id,
                'product_uom_id': quant.product_id.uom_id.id,
                'location_id': transfer_id.location_id.id,
                'location_dest_id': transfer_id.location_dest_id.id,
                'qty_done': quant.quantity,
                'picking_id': transfer_id.id
            })
        return vals

    def _get_inventory_move_values(self, qty, location_id, location_dest_id, out=False):
        context = self.env.context
        if context.get('from_warehouse_transfer'):
            return super(StockQuant, self)._get_inventory_move_values(qty, context.get('new_location_id', location_id), location_dest_id, out)
        return super(StockQuant, self)._get_inventory_move_values(qty, location_id, location_dest_id, out)
