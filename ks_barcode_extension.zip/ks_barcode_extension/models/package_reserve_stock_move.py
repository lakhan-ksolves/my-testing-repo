# -*- coding: utf-8 -*-

from odoo import models, fields


class PackageReserveStockMove(models.Model):
    _name = 'package.reserve.stock.move'
    _description = 'Package Reserve Stock Move'

    move_id = fields.Many2one('stock.move', 'Reserved Move')
    move_line_id = fields.Many2one('stock.move.line', 'Reserved Move Line')
    picked = fields.Boolean('Picked')
    done = fields.Boolean('Done')
    internal_transfer_scanner_line_id = fields.Many2one('internal.transfer.scanner.line', 'Internal Transfer Line')
    package_id = fields.Many2one('stock.quant.package', related='internal_transfer_scanner_line_id.package_id')
    picked_qty = fields.Float('Picked Qty')
