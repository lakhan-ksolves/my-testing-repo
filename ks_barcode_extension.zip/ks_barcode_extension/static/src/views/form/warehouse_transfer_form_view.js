/** @odoo-module **/

import FormView from 'web.FormView';
import ViewRegistry from 'web.view_registry';
import * as BarcodeScannerController from '@ks_barcode_extension/views/form/warehouse_transfer_form_view_controller';
import * as BarcodeScannerRenderer from '@ks_barcode_extension/views/form/warehouse_transfer_form_view_renderer';

var WarehouseTransferForm = FormView.extend({
    config: _.extend({}, FormView.prototype.config, {
        Controller: BarcodeScannerController,
        Renderer: BarcodeScannerRenderer
    }),
});

ViewRegistry.add('warehouse_transfer_form', WarehouseTransferForm);

return WarehouseTransferForm;