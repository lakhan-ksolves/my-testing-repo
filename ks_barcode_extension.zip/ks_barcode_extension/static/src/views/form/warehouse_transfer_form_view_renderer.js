/** @odoo-module **/

import FormRenderer from 'web.FormRenderer';
import core from 'web.core';
import sessionStorage from 'web.sessionStorage';

const WarehouseTransferRenderer = FormRenderer.extend({

    on_attach_callback: function () {
        this._switchBarcodeListener(true);
        this._super(...arguments);
    },

    on_detach_callback: function () {
        this._switchBarcodeListener(false);
        this._super(...arguments);
    },

    _switchBarcodeListener: function (activate) {
        if (activate) {
            core.bus.on('barcode_scanned', this, this._onBarcodeScannedHandler);
        } else {
            core.bus.off('barcode_scanned', this, this._onBarcodeScannedHandler);
        }
    },

    _onBarcodeScannedHandler: function(barcode){
        this.__parentedParent._ksOnBarcodeScanned(barcode)
    },

    _render: async function() {
        var self = this;
        await self._super(...arguments).then(function(){
            var controller = self.__parentedParent;
            var storage = sessionStorage.getItem('openSaveRecord');
            var saveRecord = storage? JSON.parse(storage) : false;
            if (saveRecord){
                controller.$buttons.find('.o_form_button_save').click();
                sessionStorage.removeItem('openSaveRecord');
            }
        });
    },
});

export default WarehouseTransferRenderer;

return WarehouseTransferRenderer;
