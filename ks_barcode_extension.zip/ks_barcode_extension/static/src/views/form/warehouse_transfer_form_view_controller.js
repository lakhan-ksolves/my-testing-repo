/** @odoo-module **/

import FormController from 'web.FormController';
import core from 'web.core';
import sessionStorage from 'web.sessionStorage';
import session from 'web.session';

var qweb = core.qweb;

const WarehouseTransferController = FormController.extend({
     init: function(){
        this._super(...arguments);
        this.operationTypeBarcodePrefix = 'OT-';
        this.commandBarcodePrefix = 'CMD-';
        this.PackageBarcodePrefix = '000084';
    },

    willStart: async function() {
        this._super(...arguments);
        this.locationBarcodePrefix = await this._ks_get_location_prefixes();
    },

    renderButtons: function($node) {
        /*
            This method is called to render the controller buttons. With this method we can render our js hidden
            input field to the form view.
        */
        var $footer = this.footerToButtons ? this.renderer.$el && this.renderer.$('footer') : null;
        var mustRenderFooterButtons = $footer && $footer.length;
        if ((this.defaultButtons && !this.$buttons) || mustRenderFooterButtons) {
            this.$buttons = $('<div/>');
            if (mustRenderFooterButtons) {
                this.$buttons.append($footer);
            } else {
                this.$buttons.append(qweb.render("WarehouseTransferFormViewButtons", {widget: this}));
                this.$buttons.on('click', '.o_form_button_edit', this._onEdit.bind(this));
                this.$buttons.on('click', '.o_form_button_create', this._onCreate.bind(this));
                this.$buttons.on('click', '.o_form_button_save', this._onSave.bind(this));
                this.$buttons.on('click', '.o_form_button_cancel', this._onDiscard.bind(this));
                this._assignSaveCancelKeyboardBehavior(this.$buttons.find('.o_form_buttons_edit'));
                this.$buttons.find('.o_form_buttons_edit').tooltip({
                    delay: {show: 200, hide:0},
                    title: function(){
                        return qweb.render('SaveCancelButton.tooltip');
                    },
                    trigger: 'manual',
                });
            }
        }
        if (this.$buttons && $node) {
            this.$buttons.appendTo($node);
        }
    },

    _ks_get_location_prefixes: async function(ev){
        var result = await this._rpc({
            route: '/warehouseTransfer/locations/prefix',
            params: {
                context: this.context,
            },
        });
        return result
    },

    _onCreate: function(ev){
        sessionStorage.removeItem('openSaveRecord');
        sessionStorage.setItem('openSaveRecord',true);
        this._super(...arguments);
    },

    _ksOnBarcodeScanned: async function(barcode){
        await this.saveRecord();
        if (!barcode){
            this.ksErrorNotification("Please Scan Again!");
        } else {
            if (this.renderer.state.data.state === 'draft' || this.renderer.state.data.state === 'assigned') {
                await this.ksProcessBarcode(barcode);
            } else {
                this.ksErrorNotification("Unable to process the barcodes in cancel and moved state.")
            }
        }
        this.reload();
    },

    _ksGetReversedBarcode: function(barcode) {
        return barcode.split('').reverse().join('');
    },

    ksProcessBarcode: async function(barcode) {
        var result = this._ksCheckBarcode(barcode);
        if (!result) {
            return;
        }
        await this._ksProcessBarcode(result.processBarcode, result.method);
    },

    _ksCheckBarcode: function(barcode) {
        const reverseBarcode = this._ksGetReversedBarcode(barcode);
        var result = this._ksCheckProcess(barcode, reverseBarcode);
        if (result.match){
            return result;
        } else {
            result = this._ksCheckOperationType(barcode, reverseBarcode);
            if (result.match) {
                if (this.renderer.state.data.state === 'draft') {
                    return result;
                } else {
                    this.ksErrorNotification("You can scan operation type only in the draft state.");
                    return false;
                }
            }
            result = this._ksCheckPackage(barcode, reverseBarcode);
            if (result.match) {
                if (this.renderer.state.data.state == 'assigned') {
                    return result;
                } else {
                    this.ksErrorNotification("You can scan only operation type and locations in the draft state.");
                    return false;
                }
            }
            result = this._ksCheckLocation(barcode, reverseBarcode);
            if (result.match) {
                return result;
            } else {
                var message = barcode + ' invalid barcode. Please scan Again.';
                this.ksErrorNotification(message);
                return false;
            }
        }
    },

    _ksCheckProcess: function(barcode, reverseBarcode) {
        var result = {processBarcode: undefined,
                      method: 'ks_action_process',
                      match: false};
        if (barcode.startsWith(this.commandBarcodePrefix)) {
            return Object.assign(result, {
                processBarcode: barcode,
                match: true
            });
        } else if (reverseBarcode.startsWith(this.commandBarcodePrefix)) {
            return Object.assign(result, {
                processBarcode: reverseBarcode,
                match: true
            });
        }
        return result
    },

    _ksCheckOperationType: function(barcode, reverseBarcode) {
        var result = {processBarcode: undefined,
                      method: 'ks_set_operation_type',
                      match: false};
        if (barcode.startsWith(this.operationTypeBarcodePrefix)) {
            return Object.assign(result, {
                processBarcode: barcode,
                match: true
            });
        } else if (reverseBarcode.startsWith(this.operationTypeBarcodePrefix)) {
            return Object.assign(result, {
                processBarcode: reverseBarcode,
                match: true
            });
        }
        return result
    },

    _ksCheckLocation: function(barcode, reverseBarcode) {
        var result = {processBarcode: undefined,
                      method: 'ks_scan_location',
                      match: false};
        var isLocation = this.locationBarcodePrefix.some((prefix) => barcode.startsWith(prefix));
        if (isLocation) {
            result.processBarcode = barcode,
            result.match = true
        } else {
            isLocation = this.locationBarcodePrefix.some((prefix) => reverseBarcode.startsWith(prefix))
            if (isLocation) {
                result.processBarcode = reverseBarcode,
                result.match = true
            }
        }
        return result
    },

    _ksCheckPackage: function(barcode, reverseBarcode) {
        var result = {processBarcode: undefined,
                      method: 'ks_scan_package',
                      match: false};
        if (barcode.startsWith(this.PackageBarcodePrefix)) {
            return Object.assign(result, {
                processBarcode: barcode,
                match: true
            });
        } else if (reverseBarcode.startsWith(this.PackageBarcodePrefix)) {
            return Object.assign(result, {
                processBarcode: reverseBarcode,
                match: true
            });
        }
        return result
    },

    _ksProcessBarcode: async function(barcode, method) {
//        await this.saveRecord();
        var scanType = 'remove';
        if (this.renderer.state.data.scan_toggle){
            scanType = 'add';
        }
        const result = await this._rpc({
            model: 'internal.transfer.scanner',
            method: method,
            args: [[this.renderer.state.res_id], barcode],
            context: {scan_type: scanType},
        });
        if (result.action) {
            this.do_action(result.action);
        } else {
            if (result.status){
                this.ksSuccessNotification(result.message);
            } else {
                this.ksErrorNotification(result.message);
            }
        }
    },

    ksSuccessNotification: function(message) {
        this.displayNotification({
            'type': 'success',
            'message': message
        });
        this._ksSuccessSound();
    },

    ksErrorNotification: function(message) {
        this.displayNotification({
            'type': 'danger',
            'message': message
        });
        this._ksErrorSound();
    },

    _ksSuccessSound: function(){
        if (typeof(Audio) !== "undefined") {
            this._audio = new Audio();
            var ext = this._audio.canPlayType("audio/ogg; codecs=vorbis") ? ".ogg" : ".mp3";
            this._audio.src = session.url("/ks_barcode_extension/static/src/audio/scanner" + ext);
            Promise.resolve(this._audio.play()).catch(_.noop);
        }
    },

    _ksErrorSound: function(){
        if (typeof(Audio) !== "undefined") {
            this._audio = new Audio();
            var ext = this._audio.canPlayType("audio/ogg; codecs=vorbis") ? ".ogg" : ".mp3";
            this._audio.src = session.url("/ks_barcode_extension/static/src/audio/error" + ext);
            Promise.resolve(this._audio.play()).catch(_.noop);
        }
    },

});

export default WarehouseTransferController;

return WarehouseTransferController;