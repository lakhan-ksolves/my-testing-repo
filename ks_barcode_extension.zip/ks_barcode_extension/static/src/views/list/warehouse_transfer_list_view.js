odoo.define('ks_barcode_extension.warehouse_transfer_list_view', function(require){
    'use strict';

    var ListController = require('web.ListController');
    var ListView = require('web.ListView');
    var ViewRegistry = require('web.view_registry');
    var sessionStorage = require('web.sessionStorage');

    var WarehouseTransferListController = ListController.extend({
        _onCreateRecord: function(){
            sessionStorage.removeItem('openSaveRecord');
            sessionStorage.setItem('openSaveRecord',true);
            this._super(...arguments);
        }
    });

    var WarehouseTransferListView = ListView.extend({
        config: _.extend({}, ListView.prototype.config, {
            Controller: WarehouseTransferListController
        }),
    });

    ViewRegistry.add('warehouse_transfer_list_view', WarehouseTransferListView);

});