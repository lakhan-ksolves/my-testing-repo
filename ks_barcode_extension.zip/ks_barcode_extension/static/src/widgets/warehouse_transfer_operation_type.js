/** @odoo-module **/

import fieldRegistry from 'web.field_registry';
import relationalFields from 'web.relational_fields';

var WarehouseTransferOperationType = relationalFields.FieldMany2One.extend({

    _onInputKeyup: function(ev) {
        try {
            this._super(ev);
        } catch (err) {
            // silently ignore RPC errors
        }
    },

    _render: function(){
        this._super(...arguments);
        this._updateButtonTemplate(this.record.data.operation_type)
    },

    _updateButtonTemplate: async function(operation_type){
        var controller = this.__parentedParent.__parentedParent;
        var controllerButtons;
        if (controller.mode === 'readonly') {
            controllerButtons = controller.$buttons.find('.o_form_buttons_view');
        } else if (controller.mode === 'edit') {
            controllerButtons = controller.$buttons.find('.o_form_buttons_edit');
        }
        if (controllerButtons) {
            var packageValidation = controllerButtons.find('.oe_package_validation');
            var scannedPackages = controllerButtons.find('.oe_scanned_package');
            if (operation_type){
                if (operation_type === 'physical_audit'){
                    packageValidation.removeClass('d-none');
                    scannedPackages.addClass('d-none');
                } else if (operation_type === 'immediate_loose') {
                    scannedPackages.addClass('d-none');
                    packageValidation.addClass('d-none');
                } else if (operation_type === 'physical_audit_product') {
                    scannedPackages.addClass('d-none');
                    packageValidation.addClass('d-none');
                } else {
                    scannedPackages.removeClass('d-none');
                    packageValidation.addClass('d-none');
                }
            } else {
                scannedPackages.addClass('d-none');
                packageValidation.addClass('d-none');
            }
        }
    }
});

fieldRegistry.add('warehouse_transfer_operation_type', WarehouseTransferOperationType)
