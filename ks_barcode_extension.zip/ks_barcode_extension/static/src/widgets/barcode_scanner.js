/** @odoo-module **/

import Widget from 'web.Widget';
import widgetRegistry from 'web.widget_registry';
import * as BarcodeScanner from '@ks_barcode_extension/webclient/barcode/barcode_scanner';


const BarcodeScannerButton = Widget.extend({
    template: 'ks_barcode_scanner.barcode_scanner',
    events: _.extend({}, Widget.prototype.events, {
        'click .o_barcode_scanner': '_onClickBarcodeScanner',
    }),

    _onClickBarcodeScanner: async function(ev){
        const barcode = await BarcodeScanner.scanBarcode();
        if (barcode) {
            this.__parentedParent.__parentedParent._ksOnBarcodeScanned(barcode);
            if ('vibrate' in window.navigator) {
                window.navigator.vibrate(100);
            }
        } else {
            this._error_notification();
            this.displayNotification({
                type: 'warning',
                message: 'Please, scan again !',
            });
        }
    },
});

widgetRegistry.add('barcode_scanner', BarcodeScannerButton);

export default BarcodeScanner;