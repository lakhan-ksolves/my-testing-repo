/** @odoo-module **/

import basicFields from 'web.basic_fields';
import fieldRegistry from 'web.field_registry';

var FieldInteger = basicFields.FieldInteger;

var packageScannerCount = FieldInteger.extend({
    _render: function(){
        this._super.apply(this, arguments);
        var buttonsDiv;
        var options = this.attrs.options;
        var renderer = this.__parentedParent;
        var controller = renderer.__parentedParent;
        var controllerButtons = controller.$buttons;
        if (options && controllerButtons.length > 0) {
            if (controller.mode === 'edit'){
                buttonsDiv = '.o_form_buttons_edit';
            } else {
                buttonsDiv = '.o_form_buttons_view';
            }
            var countElements;
            if (options.package_count){
                buttonsDiv += ' #package_count';
                countElements = $(controllerButtons[0]).find(buttonsDiv);
            } else if (options.package_limit) {
                buttonsDiv += ' #package_limit';
                countElements = $(controllerButtons[0]).find(buttonsDiv);
            } else if (options.available_pack_count) {
                buttonsDiv += ' #package_available';
                countElements = $(controllerButtons[0]).find(buttonsDiv);
            }
            if (countElements){
                for (var i=0; i<countElements.length; i++){
                    $(countElements[i]).text(this.value);
                }
            }
        }
    }
});

fieldRegistry.add('ks_package_scanner_count', packageScannerCount)
