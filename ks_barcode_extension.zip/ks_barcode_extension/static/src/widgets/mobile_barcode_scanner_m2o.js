/** @odoo-module **/

import fieldRegistry from 'web.field_registry';
import relationalFields from 'web.relational_fields';

var MobileBarcodeScanner = relationalFields.FieldMany2One.extend({

    _onInputKeyup: function(ev) {
        try {
            this._super(ev);
        } catch (err) {
            // silently ignore RPC errors
        }
    },
})

fieldRegistry.add('mobile_barcode_scanner_m2o', MobileBarcodeScanner)
