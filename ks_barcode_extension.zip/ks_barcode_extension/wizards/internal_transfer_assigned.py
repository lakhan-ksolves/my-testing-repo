
from odoo import models, fields, _
from odoo.exceptions import UserError


class InternalTransferAssigned(models.TransientModel):
    _name = 'internal.transfer.assigned'
    _description = 'Internal Transfer Assigned'

    assigned_user_id = fields.Many2one('res.users', 'Assignee')

    def ks_action_assigned(self):
        active_ids = self.env.context.get('active_ids', [])
        internal_transfers = self.env['internal.transfer.scanner'].browse(active_ids)
        for record in internal_transfers:
            if not self.assigned_user_id:
                raise UserError(_("You need to select the assigned worker first, then assign the internal transfer."))
            if record.assigned_worker_id.id == self.assigned_user_id.id:
                raise UserError(_("%s warehouse transfer is already assigned to %s user."
                                  % (record.name, self.assigned_user_id.name)))
            self.ks_check_user_limit()
            message_body = _("Assign User -> <b> %s </b>" % self.assigned_user_id.name.upper())
            record.message_post(body=message_body, partner_ids=self.assigned_user_id.partner_id.ids)
            record.write({'assigned_worker_id': self.assigned_user_id.id,
                          'state': 'assigned'})

    def ks_check_user_limit(self):
        if self.assigned_user_id.has_group('ks_barcode_extension.warehouse_transfer_manager'):
            return
        transfer_limit = self.env['ir.config_parameter'].sudo().get_param("ks_barcode_extension.transfer_limit")
        if transfer_limit:
            current_assigned_records = self.env['internal.transfer.scanner'].search([('state', '=', 'assigned'),
                                                    ('assigned_worker_id', '=', self.assigned_user_id.id)])
            if int(transfer_limit) <= int(len(current_assigned_records)):
                raise UserError(_(f"There are already {len(current_assigned_records)} Warehouse Transfer records assigned to this user. Please move or cancel them before proceeding"))
