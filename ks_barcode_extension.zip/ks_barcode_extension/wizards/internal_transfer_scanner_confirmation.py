# -*- coding: utf-8 -*-

import random
from odoo import models, fields, _
from odoo.exceptions import UserError


class InternalTransferScannerConfirmation(models.TransientModel):
    _name = 'internal.transfer.scanner.confirmation'
    _description = 'Internal Transfer Scanner Confirmation'

    def _ks_check_authorised_user(self):
        return self.env.user.has_group('ks_barcode_extension.warehouse_transfer_manager')

    name = fields.Text('Name')
    internal_transfer_scanner_id = fields.Many2one('internal.transfer.scanner', 'Scanner')
    confirmation_line_ids = fields.One2many('internal.transfer.scanner.confirmation.line', 'confirmation_id',
                                            'Confirmation Lines')
    lines_confirmation = fields.Boolean('Lines Confirmation', copy=False)
    is_authorised_user = fields.Boolean('Authorised User', default=_ks_check_authorised_user)

    def action_process(self):
        self.ensure_one()
        context = self.env.context.copy()
        if self.env.context.get('default_name'):
            context.pop('default_name')
        if self.env.context.get('default_internal_transfer_scanner_id'):
            context.pop('default_internal_transfer_scanner_id')
        if self.confirmation_line_ids:
            self.confirmation_line_ids.with_context(context).ks_transfer_lines_to_suspense()
        if self.internal_transfer_scanner_id:
            validate_response = self.internal_transfer_scanner_id.with_context(context)._ks_action_validate()
            if validate_response != True:
                return validate_response
        return {
            'type': 'ir.actions.client',
            'tag': 'reload',
        }

    def ks_action_assign_to_admin(self):
        self.ensure_one()
        admin_group_id = self.env.ref('ks_barcode_extension.warehouse_transfer_manager')
        if not admin_group_id:
            raise UserError(_("Warehouse transfer manager group is not exists in this database. Please update the "
                              "module ks_barcode_extension."))
        if not admin_group_id.users:
            raise UserError(_("There is no users are added to the %s group." % admin_group_id.name))
        if self.internal_transfer_scanner_id.assigned_worker_id.id in admin_group_id.users.ids:
            raise UserError(_("This transfer is already assigned to the administrator."))
        assigned_user_id = random.choice(admin_group_id.users)
        message_body = _("Assign User -> <b> %s </b>" % assigned_user_id.name.upper())
        self.internal_transfer_scanner_id.message_post(body=message_body, partner_ids=assigned_user_id.partner_id.ids)
        message = self.ks_action_generate_message()
        if message:
            self.internal_transfer_scanner_id.message_post(body=message)
        self.internal_transfer_scanner_id.write({'assigned_worker_id': assigned_user_id.id,
                                                 'state': 'assigned'})

    def ks_action_generate_message(self):
        message = ''
        if self.confirmation_line_ids:
            message += f"You have multiple products at the <b>{self.internal_transfer_scanner_id.location_dest_id.display_name}</b> Location."
        return message

class InternalTransferScannerConfirmationLine(models.TransientModel):
    _name = 'internal.transfer.scanner.confirmation.line'
    _description = 'Internal Transfer Scanner Confirmation Line'

    confirmation_id = fields.Many2one('internal.transfer.scanner.confirmation', 'Confirmation')
    product_id = fields.Many2one('product.product', 'Product')
    on_hand_qty = fields.Float('On-Hand Qty')
    picked_qty = fields.Float('Picked Qty')
    physical_qty = fields.Float('Physical Qty')

    def ks_transfer_lines_to_suspense(self):
        lines_to_suspense = self.filtered(lambda cl: cl.physical_qty > 0)
        if lines_to_suspense:
            transfer_id = self.confirmation_id.internal_transfer_scanner_id.with_context(suspense=True).\
                ks_create_internal_transfer('immediate')
            self.env['stock.move.line'].create(lines_to_suspense.ks_create_suspense_move_line_vals(transfer_id))

    def ks_create_suspense_move_line_vals(self, transfer_id):
        vals = []
        for line in self:
            vals.append({
                'company_id': transfer_id.company_id.id,
                'product_id': line.product_id.id,
                'product_uom_id': line.product_id.uom_id.id,
                'location_id': transfer_id.location_id.id,
                'location_dest_id': transfer_id.location_dest_id.id,
                'qty_done': line.physical_qty,
                'picking_id': transfer_id.id
            })
        return vals

class SoloProductConfirmation(models.TransientModel):
    _name = 'internal.transfer.solo.product.confirmation'
    _description = 'Solo SKU Confirmation'

    internal_transfer_scanner_id = fields.Many2one('internal.transfer.scanner', 'Scanner')
    message = fields.Text(string='Message')

    def action_process(self):
        self.internal_transfer_scanner_id.with_context(ks_solo_sku=True)._ks_action_validate()

    def action_assign_to_admin(self):
        self.ensure_one()
        admin_group_id = self.env.ref('ks_barcode_extension.warehouse_transfer_manager')
        if not admin_group_id:
            raise UserError(_("Warehouse transfer manager group is not exists in this database. Please update the "
                              "module ks_barcode_extension."))
        if not admin_group_id.users:
            raise UserError(_("There is no users are added to the %s group." % admin_group_id.name))
        if self.internal_transfer_scanner_id.assigned_worker_id.id in admin_group_id.users.ids:
            raise UserError(_("This transfer is already assigned to the administrator."))
        assigned_user_id = random.choice(admin_group_id.users)
        message_body = _("Assign User -> <b> %s </b> <br/> These product SKUs cannot be transferred together without admin approval." % assigned_user_id.name.upper())
        self.internal_transfer_scanner_id.message_post(body=message_body, partner_ids=assigned_user_id.partner_id.ids)
        self.internal_transfer_scanner_id.write({'assigned_worker_id': assigned_user_id.id,
                                                 'state': 'assigned'})