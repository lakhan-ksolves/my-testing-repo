# -*- coding: utf-8 -*-

import random
from odoo import models, fields, api, _
from odoo.exceptions import UserError


class InternalTransferProductSelection(models.TransientModel):
    _name = 'internal.transfer.product.selection'
    _description = 'Internal Transfer Product Selection'

    def _ks_get_finished_categ(self):
        return self.env['product.category'].search([('finished_category', '=', True)], limit=1, order='id asc')

    def _ks_check_authorised_user(self):
        return self.env.user.has_group('ks_barcode_extension.warehouse_transfer_manager')

    name = fields.Text('Name')
    product_id = fields.Many2one('product.product', 'Product')
    another_product = fields.Boolean('None of the above')
    product_selection_ids = fields.One2many('internal.transfer.product.selection.line', 'product_selection_id', 'Product Selection')
    ready_to_done = fields.Boolean('Ready to Done', compute='_ks_compute_ready_to_done')
    internal_transfer_scanner_id = fields.Many2one('internal.transfer.scanner', 'Internal Transfer')
    product_categ_id = fields.Many2one('product.category', 'Category', default=_ks_get_finished_categ)
    confirmation = fields.Boolean('Confirmation', copy=False)
    products_not_to_add = fields.Many2many('product.product')
    is_authorised_user = fields.Boolean('Authorised User', default=_ks_check_authorised_user)
    is_quant_zero = fields.Boolean('Is Quant Zero?')

    def _ks_compute_products_not_to_add(self):
        for record in self:
            products_not_to_add = record.product_selection_ids.mapped('product_id')
            record.products_not_to_add = [(6, 0, products_not_to_add.ids)]

    @api.depends('another_product', 'product_selection_ids.add_product')
    def _ks_compute_ready_to_done(self):
        for record in self:
            ready_to_done = True
            if not record.another_product and not record.confirmation:
                product_selected = record.product_selection_ids.filtered(lambda ps: ps.add_product)
                if len(product_selected) != 1:
                    ready_to_done = False
            record.ready_to_done = ready_to_done

    def ks_action_done(self):
        self.ensure_one()
        add_lines_vals = []
        suspense_lines_vals = []
        free_bin = False
        suspense_lines = []
        selected_line = self.product_selection_ids.filtered(lambda line: line.add_product)
        multi_location = self.internal_transfer_scanner_id.warehouse_id.multi_location_pick
        if selected_line:
            vals = self.internal_transfer_scanner_id.ks_prepare_vals_for_products(selected_line.quant_id, multi_location)
            add_lines_vals.append((0, 0, vals))
        elif self.is_quant_zero and not self.product_id:
            raise UserError(_("Please select Product First."))
        elif self.product_id and self.is_quant_zero:
            add_lines_vals.append((0, 0, self.ks_prepare_internal_transfer_vals()))
        else:
            if self.another_product:
                if not self.product_id:
                    free_bin = True
                else:
                    add_lines_vals.append((0, 0, self.ks_prepare_internal_transfer_vals()))
            else:
                for product_line in self.product_selection_ids.filtered(lambda line: line.physical_qty > 0):
                    vals = self.internal_transfer_scanner_id.ks_prepare_vals_for_products(product_line.quant_id,
                                                                                          multi_location)
                    add_lines_vals.append((0, 0, vals))
        if not self.confirmation:
            suspense_lines = self.product_selection_ids - selected_line
            suspense_lines = suspense_lines.filtered(lambda line: line.physical_qty > 0)
        if free_bin and not suspense_lines:
            raise UserError(_("This location is already empty."))
        if suspense_lines:
            for suspense_line in suspense_lines:
                suspense_lines_vals.append((0, 0, self.ks_prepare_internal_transfer_vals(suspense_line=suspense_line)))
        self.internal_transfer_scanner_id.write({'internal_transfer_scanner_lines': add_lines_vals,
                                                 'product_lines_to_suspense':  suspense_lines_vals,
                                                 'free_bin': free_bin})

    def ks_prepare_internal_transfer_vals(self, suspense_line=None):
        vals = {}
        if suspense_line:
            vals.update({'product_id': suspense_line.product_id.id,
                         'quantity': suspense_line.physical_qty})
        else:
            vals.update({'product_id': self.product_id.id,
                         'scanned': True})
        return vals

    def ks_action_assign_to_admin(self):
        self.ensure_one()
        admin_group_id = self.env.ref('ks_barcode_extension.warehouse_transfer_manager')
        if not admin_group_id:
            raise UserError(_("Warehouse transfer manager group is not exists in this database. Please update the "
                              "module ks_barcode_extension."))
        if not admin_group_id.users:
            raise UserError(_("There is no users are added to the %s group." % admin_group_id.name))
        if self.internal_transfer_scanner_id.assigned_worker_id.id in admin_group_id.users.ids:
            raise UserError(_("This transfer is already assigned to the administrator."))
        assigned_user_id = random.choice(admin_group_id.users)
        message_body = _("Assign User -> <b> %s </b>" % assigned_user_id.name.upper())
        self.internal_transfer_scanner_id.message_post(body=message_body, partner_ids=assigned_user_id.partner_id.ids)
        message = self.ks_action_generate_message()
        if message:
            self.internal_transfer_scanner_id.message_post(body=message)
        self.internal_transfer_scanner_id.write({'assigned_worker_id': assigned_user_id.id,
                                                 'state': 'assigned'})

    def ks_action_generate_message(self):
        message = ''
        selected_line = self.product_selection_ids.filtered(lambda line: line.add_product)
        if self.product_id:
            message += f"Add the Product to the Location <b>'{self.product_id.name}'</b>\n"
        if selected_line and not self.another_product:
            message += "Selected the line where Product name is "
            for line in selected_line:
                message += f"<b>'{line.product_id.name}'</b>."
        if self.another_product and not self.product_id:
            message += "Checked None of the above\n"
        return message


class InternalTransferProductSelectionLine(models.TransientModel):
    _name = 'internal.transfer.product.selection.line'
    _description = 'Internal Transfer Product Selection Line'

    product_selection_id = fields.Many2one('internal.transfer.product.selection')
    product_id = fields.Many2one('product.product', 'Product')
    add_product = fields.Boolean('Select')
    physical_qty = fields.Float('Physical Qty')
    quant_id = fields.Many2one('stock.quant', 'Quant')
    picked_qty = fields.Float('Picked Qty')
    on_hand_qty = fields.Float('On-Hand Qty')
