# -*- coding: utf-8 -*-

{
    'name': 'Barcode Extension',
    'version': '15.3.0.5',
    'summary': 'Barcode Extension.',
    'depends': ['base', 'stock', 'web_enterprise', 'web', 'barcodes', 'picking_report'],
    'author': 'Ksolves India Pvt. Ltd.',
    'data': [
        # data
        'data/data.xml',
        'data/validate_cron.xml',
        # security
        'security/security.xml',
        'security/ir.model.access.csv',
        # report templates
        'reports/report_process_barcode_template_view.xml',
        'reports/report_location_qr_code_template.xml',
        'reports/report_process_qr_code_template.xml',
        'reports/report_operation_type_qr.xml',
        # reports
        'reports/report_process_barcode_view.xml',
        'reports/report_qr_code.xml',
        # views
        'views/internal_transfer_scanner_view.xml',
        'views/stock_location_view.xml',
        'views/res_config_settings_view.xml',
        'views/internal_transfer_process_barcode_view.xml',
        'views/stock_picking_type_view.xml',
        # 'views/product_template_view.xml',
        'views/stock_quant_view.xml',
        'views/stock_warehouse_view.xml',
        'views/stock_quant_packages_view.xml',
        'views/product_category_view.xml',
        'views/product_template_inherit.xml',
        # wizards
        'wizards/internal_transfer_scanner_confirmation_view.xml',
        'wizards/internal_transfer_assigned_view.xml',
        'wizards/internal_transfer_product_selection_view.xml',
        # menus
        'views/internal_transfer_menu.xml'
    ],
    'assets': {
            'web.assets_backend': [
                'ks_barcode_extension/static/src/webclient/barcode/**/*.js',
                'ks_barcode_extension/static/src/views/**/*.js',
                'ks_barcode_extension/static/src/**/*.js',
            ],
            'web.assets_qweb': [
                'ks_barcode_extension/static/src/xml/templates.xml',
                'ks_barcode_extension/static/src/widgets/barcode_scanner.xml'
            ]
    },
    'installable': True,
    'auto_install': False,
    'license': 'LGPL-3',
}
