# -*- coding: utf-8 -*-

from odoo.http import Controller, request, route


class WarehouseTransfer(Controller):
    @route('/warehouseTransfer/locations/prefix', type='json', auth="user")
    def selector(self, **kw):
        warehouses = request.env['stock.warehouse'].search([])
        codes = warehouses.mapped('code')
        location_prefixes = ["%s/" % code for code in codes]
        return location_prefixes
