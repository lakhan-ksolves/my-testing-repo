from odoo import models, fields, api
from odoo.exceptions import ValidationError

class StockMove(models.Model):
    _inherit = 'stock.move'

    product_tmpl_id = fields.Many2one(
        related='product_id.product_tmpl_id',
        string="Product Template",
        store=True,
        readonly=True
    )

    warranty_line_id = fields.Many2one(
        "provider.warranty.line",
        string="Warranty Provider",
        domain="[('id', 'in', available_warranty_ids)]"
    )

    warranty_duration_id = fields.Many2one(
        "warranty.duration",
        string="Warranty Duration",
        domain="[('id', 'in', available_duration_ids)]",
    )

    warranty_option_id = fields.Many2one(
        "product.warranty.option",
        string="Warranty",
        domain="[('product_tmpl_id', '=', product_tmpl_id)]",
        help="Select warranty (Provider - Duration).",
    )

    available_warranty_ids = fields.Many2many(
        'provider.warranty.line',
        compute='_compute_available_warranties',
        string='Available Warranties'
    )

    available_duration_ids = fields.Many2many(
        "warranty.duration",
        compute="_compute_available_durations",
        string="Available Durations",
    )

    @api.depends('product_id', 'picking_id.partner_id')
    def _compute_available_warranties(self):
        """Compute available warranties based on product's seller_ids and picking partner."""
        for move in self:
            if move.product_id:
                move.available_warranty_ids = self.env['provider.warranty.line'].search([
                    ('product_tmpl_id', '=', move.product_tmpl_id.id)
                ])
            else:
                move.available_warranty_ids = False

    @api.depends("warranty_line_id")
    def _compute_available_durations(self):
        for move in self:
            if move.warranty_line_id:
                move.available_duration_ids = move.warranty_line_id.duration_ids
            else:
                move.available_duration_ids = False

    @api.onchange("warranty_option_id")
    def _onchange_warranty_option_id(self):
        if self.warranty_option_id:
            self.warranty_line_id = self.warranty_option_id.warranty_line_id
            self.warranty_duration_id = self.warranty_option_id.duration_id
        else:
            self.warranty_line_id = False
            self.warranty_duration_id = False

    warranty_provider_name = fields.Char(
        string="Warranty Provider Name",
    )

    warranty_months = fields.Integer(
        related='warranty_duration_id.months',
        string="Warranty (Months)",
    )

    def _prepare_move_line_vals(self, quantity=None, reserved_quant=None):
        """Autopopulate warranty from move to move line."""
        vals = super()._prepare_move_line_vals(quantity, reserved_quant)
        # Autofill warranty from stock.move
        # vals.update({
        # 'warranty_line_id': self.warranty_line_id.id if self.warranty_line_id else False,
        # 'warranty_duration_id': self.warranty_duration_id.id if self.warranty_duration_id else False,
        # 'warranty_option_id': self.warranty_option_id.id if self.warranty_option_id else False,
        # 'warranty_provider_name': self.warranty_line_id.vendor_id.name if self.warranty_line_id else False
        # })

        # If the new move line is tied to a lot, pull the warranty from that lot.
        # The lot is the source of truth.
        if vals.get('lot_id'):
            lot = self.env['stock.lot'].browse(vals['lot_id'])
            if lot.warranty_option_id:
                vals['warranty_option_id'] = lot.warranty_option_id.id
                return vals

        # Add warranty from product if there is only one
        product_tmpl = self.product_id.product_tmpl_id
        if product_tmpl and len(product_tmpl.provider_warranty_ids) == 1:
            warranty_line = product_tmpl.provider_warranty_ids[0]
            if len(warranty_line.duration_ids) == 1:
                warranty_options = self.env['product.warranty.option'].search([
                    ('warranty_line_id', '=', warranty_line.id),
                    ('duration_id', '=', warranty_line.duration_ids.id)
                ])
                if warranty_options:
                    self.warranty_option_id = warranty_options[0]
                    vals.update({
                        'warranty_option_id': self.warranty_option_id.id if self.warranty_option_id else False,
                    })

        return vals

    @api.onchange('warranty_line_id', 'warranty_duration_id', 'warranty_option_id')
    def _onchange_provider_warranty_id(self):
        self.move_line_ids.write({
            'warranty_line_id': self.warranty_line_id.id if self.warranty_line_id else False,
            'warranty_duration_id': self.warranty_duration_id.id if self.warranty_duration_id else False,
            'warranty_option_id': self.warranty_option_id.id if self.warranty_option_id else False,
            'warranty_provider_name': self.warranty_line_id.vendor_id.name if self.warranty_line_id else False
        })

class StockMoveLine(models.Model):
    _inherit = 'stock.move.line'

    warranty_line_id = fields.Many2one(
        "provider.warranty.line",
        string="Warranty Provider",
        domain="[('id', 'in', available_warranty_ids)]"
    )

    warranty_duration_id = fields.Many2one(
        "warranty.duration",
        string="Warranty Duration",
        domain="[('id', 'in', available_duration_ids)]",
    )

    warranty_option_id = fields.Many2one(
        "product.warranty.option",
        string="Warranty",
        domain="[('product_tmpl_id', '=', product_tmpl_id)]",
        help="Select warranty (Provider - Duration).",
    )

    available_warranty_ids = fields.Many2many(
        'provider.warranty.line',
        compute='_compute_available_warranties',
        string='Available Warranties'
    )

    available_duration_ids = fields.Many2many(
        "warranty.duration",
        compute="_compute_available_durations",
        string="Available Durations",
    )

    warranty_required = fields.Boolean(
        string="Warranty Required",
        compute='_compute_warranty_required',
        store=False
    )

    warranty_start_date = fields.Date("Warranty Start Date")
    warranty_end_date = fields.Date("Warranty End Date")

    def _compute_warranty_required(self):
        for line in self:
            line.warranty_required = line.product_id.product_tmpl_id.tracking != 'none'

    @api.depends('product_id', 'picking_id.partner_id')
    def _compute_available_warranties(self):
        """Compute available warranties based on product's seller_ids and picking partner."""
        for line in self:
            if line.product_id:
                line.available_warranty_ids = self.env['provider.warranty.line'].search([
                    ('product_tmpl_id', '=', line.product_tmpl_id.id)
                ])
            else:
                line.available_warranty_ids = False

    @api.onchange("warranty_option_id")
    def _onchange_warranty_option_id(self):
        if self.warranty_option_id:
            self.warranty_line_id = self.warranty_option_id.warranty_line_id
            self.warranty_duration_id = self.warranty_option_id.duration_id
        else:
            self.warranty_line_id = False
            self.warranty_duration_id = False

    @api.depends("warranty_line_id")
    def _compute_available_durations(self):
        for line in self:
            if line.warranty_line_id:
                line.available_duration_ids = line.warranty_line_id.duration_ids
            else:
                line.available_duration_ids = False

    product_tmpl_id = fields.Many2one(
        related='product_id.product_tmpl_id',
        string="Product Template",
        store=True,
        readonly=True
    )

    warranty_provider_name = fields.Char(
        string="Warranty Provider Name",
    )

    warranty_months = fields.Integer(
        related='warranty_duration_id.months',
        string="Warranty (Months)",
    )

    # Helper field to check if product has warranty enabled
    warranty_enabled = fields.Boolean(
        related='product_id.product_tmpl_id.provider_warranty_enabled',
        string="Warranty Enabled",
        readonly=True
    )    
    def _get_fields_stock_barcode(self):
        fields = super()._get_fields_stock_barcode()
        fields += [
            "warranty_line_id",
            "warranty_duration_id",
            "warranty_option_id",
            "product_tmpl_id",
            "warranty_provider_name",
            "warranty_months"
        ]
        return fields

    @api.constrains('warranty_line_id', 'product_id')
    def _check_warranty_validity(self):
        """Ensure selected warranty belongs to the product."""
        for line in self:
            if line.warranty_line_id and line.product_id:
                warranty = line.warranty_line_id
                if warranty.product_tmpl_id != line.product_id.product_tmpl_id:
                    raise ValidationError(
                        f"The selected warranty does not belong to product '{line.product_id.display_name}'."
                    )

    @api.onchange('lot_id', 'quant_id')
    def _onchange_lot_quant_id(self):
         for move_line in self:
            lot = move_line.quant_id.lot_id
            if lot and lot.warranty_option_id:
                move_line.warranty_option_id = lot.warranty_option_id
            elif lot and lot.product_id: # Try to autofill from product if lot has no warranty
                product_tmpl = lot.product_id.product_tmpl_id
                if product_tmpl and len(product_tmpl.provider_warranty_ids) == 1:
                    warranty_line = product_tmpl.provider_warranty_ids[0]
                    if len(warranty_line.duration_ids) == 1:
                        warranty_options = self.env['product.warranty.option'].search([
                            ('warranty_line_id', '=', warranty_line.id),
                            ('duration_id', '=', warranty_line.duration_ids.id)
                        ])
                        if warranty_options:
                            move_line.warranty_option_id = warranty_options[0]

    @api.onchange('product_id', 'move_id')
    def _onchange_product_warranty_autofill(self):
        """
        Auto-fill warranty from parent stock.move when:
        1. Product has warranty enabled
        2. Parent move has warranty configured
        """
        if not self.product_id or not self.warranty_enabled:
            self.warranty_line_id = False
            return

        # Auto-fill from parent stock.move if available
        if self.move_id and self.move_id.warranty_line_id and not self.warranty_line_id:
            self.warranty_line_id = self.move_id.warranty_line_id
            self.warranty_duration_id = self.move_id.warranty_duration_id
            self.warranty_option_id = self.move_id.warranty_option_id
            return

        # Auto-select if only one warranty available for this vendor
        options = self.env['product.warranty.option'].search([
            ('product_tmpl_id', '=', self.product_tmpl_id.id)
        ])

        # Auto-select if only one warranty available
        if len(options) == 1:
            self.warranty_option_id = options[0]
            self._onchange_warranty_option_id()
        elif len(options) == 0:
            self.warranty_option_id = False
            self._onchange_warranty_option_id()

    def write(self, vals):
        """
        When warranty is changed on move line, optionally sync back to move
        if all lines have the same warranty (keep move as summary).
        It also syncs the warranty to the lot record and restores it if cleared.
        """
        res = super(StockMoveLine, self).write(vals)

        # If warranty fields are updated, check if we should update parent move
        if 'warranty_line_id' in vals or 'warranty_duration_id' in vals or 'warranty_option_id' in vals:
            for line in self:
                if line.move_id:
                    self._sync_warranty_to_move(line.move_id)

        # If the lot_id or the warranty was changed/added during a write operation add same to lot record
        # Also, if warranty was cleared, restore it from lot.
        for line in self:
            # A process (like generating lot names) might have cleared the warranty.
            # We restore it from the lot. This will trigger another write.
            # The condition will be false in the next call, preventing an infinite loop.
            if not line.warranty_option_id and line.lot_id and line.lot_id.warranty_option_id:
                line.write({'warranty_option_id': line.lot_id.warranty_option_id.id})
            # If the line has a warranty but the lot doesn't, sync it.
            elif line.lot_id and line.warranty_option_id and not line.lot_id.warranty_option_id:
                line.lot_id.sudo().write({'warranty_option_id': line.warranty_option_id.id})
        return res

    def _sync_warranty_to_move(self, move):
        """
        Optional: Sync warranty back to stock.move if all lines have same warranty.
        This keeps the move as a summary of its lines.
        """
        if not move or not move.move_line_ids:
            return

        # Get all warranties from move lines
        warranties = move.move_line_ids.mapped('warranty_line_id')
        
        # If all lines have the same warranty, update the move
        if len(warranties) == 1 and warranties:
            durations = move.move_line_ids.mapped('warranty_duration_id')
            options = move.move_line_ids.mapped('warranty_option_id')
            move.write({
                'warranty_line_id': warranties.id,
                'warranty_duration_id': durations.id if len(durations) == 1 else False,
                'warranty_option_id': options.id if len(options) == 1 else False,
            })
        elif len(warranties) > 1:
            # Multiple different warranties - clear move warranty
            move.write({
                'warranty_line_id': False,
                'warranty_duration_id': False,
                'warranty_option_id': False,
            })

    def create(self, vals_list):
        lines = super(StockMoveLine, self).create(vals_list)
        for line in lines:
            # If the lot_id or the warranty was added during a write operation add same to lot record
            if line.lot_id and line.warranty_option_id and not line.lot_id.warranty_option_id:
                line.lot_id.sudo().write({'warranty_option_id': line.warranty_option_id.id})
        return lines
