from . import provider_warranty
from . import product
from . import purchase_order
from . import stock_move
# from . import stock_quant
from . import stock_picking
from . import sale_order
from . import pos_order
from . import account_move
from . import stock_lot
