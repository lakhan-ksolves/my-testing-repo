from odoo import api, fields, models
from dateutil.relativedelta import relativedelta

class AccountMove(models.Model):
    _inherit = 'account.move'

    stock_move_line_ids = fields.Many2many(
        'stock.move.line',
        compute='_compute_stock_move_line_ids',
        string='Related Stock Move Lines',
    )
    stock_move_line_count = fields.Integer(
        compute='_compute_stock_move_line_ids',
        string='Stock Move Line Count',
    )

    def _compute_stock_move_line_ids(self):
        for move in self:
            move_lines = self.env['stock.move.line']
            if move.move_type == 'out_invoice':
                # Fetch sale lines from invoice lines
                sale_lines = move.invoice_line_ids.mapped('sale_line_ids')
                # Fetch stock moves from sale lines
                stock_moves = sale_lines.mapped('move_ids')
                # Filter done and outgoing move lines
                move_lines = stock_moves.mapped('move_line_ids').filtered(
                    lambda ml: ml.state == 'done' and ml.move_id.picking_type_id.code == 'outgoing'
                )
            move.stock_move_line_ids = move_lines
            move.stock_move_line_count = len(move_lines)

    def action_view_stock_move_lines(self):
        self.ensure_one()
        return {
            'name': 'Stock Move Lines',
            'type': 'ir.actions.act_window',
            'view_mode': 'tree',
            'views': [(self.env.ref('purchase_warranty_provider.stock_move_line_warranty_view').id, 'tree')],
            'res_model': 'stock.move.line',
            'domain': [('id', 'in', self.stock_move_line_ids.ids)],
            'context': {'create': False, 'edit': False},
        }

    def set_warranty_dates(self):
        # Set start date of warranty = invoice date; warranty_end_date = duration months
        self.ensure_one()
        if not self.stock_move_line_count: return #If there is no move line then return
        warranty_line = self.stock_move_line_ids.filtered_domain([('warranty_option_id','!=',False)])
        for line in warranty_line:
            months_to_add = line.warranty_option_id.duration_id.months
            if not months_to_add:
                continue
            line.sudo().write({
                'warranty_start_date': self.invoice_date,
                'warranty_end_date': self.invoice_date + relativedelta(months= months_to_add)
            })

    def action_post(self):
        res = super().action_post()
        # When an invoice is posted set warranty to the outgoing move lines
        customer_invoices = self.filtered_domain([('move_type','=','out_invoice')])
        for invoice in customer_invoices:
            invoice.set_warranty_dates()
        return res

class AccountMoveLine(models.Model):
    _inherit = "account.move.line"

    warranty_details = fields.Text(
        string="Warranty",
        compute="_compute_warranty_details",
        help="Lot/Serial number with warranty details.",
    )

    # Many2many to store multiple warranties (one per lot/serial number)
    warranty_line_ids = fields.Many2many(
        "provider.warranty.line",
        "account_move_line_warranty_line_rel",
        "move_line_id",
        "warranty_line_id",
        string="Warranty Providers",
    )

    # Many2many to store specific warranty options (Vendor - Duration)
    warranty_option_ids = fields.Many2many(
        "product.warranty.option",
        "account_move_line_warranty_option_rel",
        "move_line_id",
        "warranty_option_id",
        string="Warranty Options",
    )

    @api.depends("sale_line_ids", "sale_line_ids.move_ids", "sale_line_ids.move_ids.move_line_ids", "warranty_line_ids", "warranty_option_ids")
    def _compute_warranty_details(self):
        """Compute warranty details showing lot/serial number with warranty info."""
        for line in self:
            warranty_info_list = []

            # First check if warranty_option_ids is set directly (from POS)
            if line.warranty_option_ids:
                for option in line.warranty_option_ids:
                    warranty_info_list.append(option.display_name or "")
            # Then check warranty_line_ids (from POS fallback)
            elif line.warranty_line_ids:
                for warranty in line.warranty_line_ids:
                    warranty_info_list.append(warranty.display_name or "")
            else:
                # Get sale order line(s) linked to this invoice line
                sale_lines = line.sale_line_ids

                for sale_line in sale_lines:
                    # Get stock move lines from the sale order line's stock moves
                    move_lines = sale_line.move_ids.mapped('move_line_ids').filtered(
                        lambda ml: ml.lot_id and ml.state == 'done'
                    )

                    for move_line in move_lines:
                        lot_name = move_line.lot_id.name or ""

                        # Get warranty details from stock.move.line
                        if move_line.warranty_option_id:
                            warranty_text = move_line.warranty_option_id.display_name or ""
                        elif move_line.warranty_line_id:
                            warranty_text = move_line.warranty_line_id.display_name or ""
                        else:
                            warranty_text = "15 days Return"

                        if lot_name:
                            warranty_info_list.append(f"{lot_name} - {warranty_text}")

                # Fallback to sale line warranty if no stock move lines found
                if not warranty_info_list:
                    sale_line = sale_lines[:1]
                    if sale_line:
                        if sale_line.warranty_option_id:
                            warranty_info_list.append(sale_line.warranty_option_id.display_name or "")
                        elif sale_line.warranty_line_id:
                            warranty_info_list.append(sale_line.warranty_line_id.display_name or "")

            # Default fallback
            if not warranty_info_list:
                warranty_info_list.append("15 days Return")

            line.warranty_details = "\n".join(warranty_info_list)
