from odoo import models, fields, api


class PosOrder(models.Model):
    _inherit = "pos.order"

    def _get_fields_for_order_line(self):
        fields = super(PosOrder, self)._get_fields_for_order_line()
        fields.extend([
            'warranty_line_ids',
            'warranty_option_ids',
        ])
        return fields

    @api.model
    def _get_invoice_lines_values(self, line_values, pos_order_line):
        res = super(PosOrder, self)._get_invoice_lines_values(line_values, pos_order_line)
        # Transfer warranty_line_ids and warranty_option_ids (Many2many) to invoice line
        if pos_order_line.warranty_line_ids:
            res.update({
                'warranty_line_ids': [(6, 0, pos_order_line.warranty_line_ids.ids)],
            })
        if pos_order_line.warranty_option_ids:
            res.update({
                'warranty_option_ids': [(6, 0, pos_order_line.warranty_option_ids.ids)],
            })
        return res


class PosOrderLine(models.Model):
    _inherit = "pos.order.line"

    # Many2many fields to store multiple warranties (one per lot/serial number)
    warranty_line_ids = fields.Many2many(
        "provider.warranty.line",
        "pos_order_line_warranty_line_rel",
        "pos_order_line_id",
        "warranty_line_id",
        string="Warranty Providers",
    )
    warranty_option_ids = fields.Many2many(
        "product.warranty.option",
        "pos_order_line_warranty_option_rel",
        "pos_order_line_id",
        "warranty_option_id",
        string="Warranty Options",
    )

    # Computed field for display on POS receipt
    warranty_details = fields.Char(
        string="Warranty Details",
        compute="_compute_warranty_details",
    )

    @api.depends('warranty_line_ids', 'warranty_option_ids')
    def _compute_warranty_details(self):
        for line in self:
            details = []
            # Prioritize options as they have "Vendor - Duration"
            if line.warranty_option_ids:
                for option in line.warranty_option_ids:
                    details.append(option.display_name or "")
            elif line.warranty_line_ids:
                for warranty in line.warranty_line_ids:
                    details.append(warranty.display_name or "")
            line.warranty_details = ", ".join(details) if details else "15 days Return"

    @api.model
    def _order_line_fields(self, line, session_id=None):
        """Override to extract warranty IDs from JS data (comes as array of [id, name] tuples)."""
        line = super()._order_line_fields(line, session_id)

        if line and line[2]:
            line_data = line[2]

            # Extract warranty_line_ids - JS sends as array of [id, name] or [{id, display_name}]
            if 'warranty_line_ids' in line_data:
                warranty_lines = line_data.get('warranty_line_ids') or []
                ids = self._extract_ids_from_list(warranty_lines)
                line_data['warranty_line_ids'] = [(6, 0, ids)] if ids else False

            # Extract warranty_option_ids
            if 'warranty_option_ids' in line_data:
                warranty_options = line_data.get('warranty_option_ids') or []
                ids = self._extract_ids_from_list(warranty_options)
                line_data['warranty_option_ids'] = [(6, 0, ids)] if ids else False

        return line

    def _extract_ids_from_list(self, data_list):
        """Extract IDs from a list of dicts, tuples, or integers."""
        ids = []
        if not data_list:
            return ids
        
        for item in data_list:
            if isinstance(item, dict):
                item_id = item.get('id')
                if item_id:
                    ids.append(item_id)
            elif isinstance(item, (list, tuple)) and len(item) >= 1:
                ids.append(item[0])
            elif isinstance(item, int):
                ids.append(item)
        return ids

    def _export_for_ui(self, orderline):
        result = super()._export_for_ui(orderline)
        # Export warranty data as list of dicts for JS
        result['warranty_line_ids'] = orderline.warranty_line_ids.read(['id', 'display_name']) if orderline.warranty_line_ids else []
        result['warranty_option_ids'] = orderline.warranty_option_ids.read(['id', 'display_name']) if orderline.warranty_option_ids else []
        result['warranty_details'] = orderline.warranty_details
        return result

    @api.onchange('pack_lot_lines')
    def onchange_pack_lot_ids(self):
        """Update warranty when lot lines change."""
        for line in self:
            if line.pack_lot_lines:
                lot_names = line.pack_lot_lines.mapped('lot_name')
                lots = self.env['stock.lot'].search([('name', 'in', lot_names)])
                if lots:
                    move_lines = self.env['stock.move.line'].search([
                        ('lot_id', 'in', lots.ids),
                        ('warranty_line_id', '!=', False)
                    ])
                    if move_lines:
                        # Collect all warranty_line_ids and warranty_option_ids from move lines
                        warranty_line_ids = move_lines.mapped('warranty_line_id').ids
                        warranty_option_ids = move_lines.mapped('warranty_option_id').filtered(lambda o: o).ids
                        line.warranty_line_ids = [(6, 0, warranty_line_ids)]
                        line.warranty_option_ids = [(6, 0, warranty_option_ids)]

    def write(self, vals):
        res = super().write(vals)
        if 'pack_lot_ids' in vals:
            for line in self:
                if line.pack_lot_ids:
                    lot_names = line.pack_lot_ids.mapped('lot_name')
                    lots = self.env['stock.lot'].search([('name', 'in', lot_names)])
                    if lots:
                        move_lines = self.env['stock.move.line'].search([
                            ('lot_id', 'in', lots.ids),
                            ('warranty_line_id', '!=', False)
                        ])
                        if move_lines:
                            warranty_line_ids = move_lines.mapped('warranty_line_id').ids
                            warranty_option_ids = move_lines.mapped('warranty_option_id').filtered(lambda o: o).ids
                            line.warranty_line_ids = [(6, 0, warranty_line_ids)]
                            line.warranty_option_ids = [(6, 0, warranty_option_ids)]
        return res
