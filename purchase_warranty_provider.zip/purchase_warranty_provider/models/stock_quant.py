from odoo import models, fields, api
from odoo.exceptions import ValidationError


class StockQuant(models.Model):
    _inherit = 'stock.quant'

    provider_type = fields.Selection([
        ('brand', 'Brand'),
        ('vendor', 'Vendor'),
    ], string="Provider Type")

    warranty_line_id = fields.Many2one(
        "provider.warranty.line",
        string="Warranty",
        domain="[('product_tmpl_id', '=', product_tmpl_id), ('active', '=', True)]"
    )

    warranty_months = fields.Integer(
        string="Warranty (Months)",
        related='warranty_line_id.warranty_months',
        store=True,
    )


    product_tmpl_id = fields.Many2one(
        related='product_id.product_tmpl_id',
        string="Product Template",
        store=True,
        readonly=True
    )