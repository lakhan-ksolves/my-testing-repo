from odoo import api, fields, models, tools
import re
from odoo.exceptions import ValidationError


class WarrantyDuration(models.Model):
    _name = "warranty.duration"
    _description = "Warranty Duration"
    _rec_name = "name"

    name = fields.Char(string="Duration Name", required=True)
    months = fields.Integer(string="Months")

    _sql_constraints = [
        ('name_uniq', 'unique (name)', 'The duration name must be unique!')
    ]

    def create(self, vals):
        if vals.get('name'):
            months = vals['name'].split(' ')[0]
            if months.isdigit():
                vals['months'] = int(months)
            else:
                vals['months'] = 0
        return super().create(vals)

class ProviderWarrantyLine(models.Model):
    _name = "provider.warranty.line"
    _description = "Provider Warranty Configuration"
    _rec_name = "display_name"

    product_tmpl_id = fields.Many2one(
        "product.template",
        string="Product",
        required=True,
        ondelete="cascade",
        index=True,
    )

    vendor_id = fields.Many2one(
        "res.partner",
        string="Vendor",
        domain="[('supplier_rank', '>', 0)]",
        help="Vendor providing this warranty.",
        required=True,
    )

    duration_ids = fields.Many2many(
        "warranty.duration",
        string="Available Durations",
        required=True,
    )

    active = fields.Boolean(default=True, string="Active")

    display_name = fields.Char(
        string="Display Name",
        compute="_compute_display_name",
        store=True,
    )

    @api.constrains('duration_ids', 'product_tmpl_id')
    def _check_duration_for_untracked_products(self):
        for record in self:
            if record.product_tmpl_id.tracking == 'none' and len(record.duration_ids) > 1:
                raise ValidationError("Products not tracked by serial number can only have one warranty duration.")

    @api.depends('vendor_id', 'product_tmpl_id')
    def _compute_display_name(self):
        for rec in self:
            vendor_name = rec.vendor_id.name if rec.vendor_id else "Unknown Vendor"
            rec.display_name = f"{vendor_name} Warranty"

    def write(self, vals):
        res = super().write(vals)
        if 'active' in vals:
            # Make sure a product doesn't have more than required warranty
            self.mapped('product_tmpl_id')._check_provider_warranty_ids()
        return res

    def create(self, vals_list):
        res = super().create(vals_list)
        # Make sure a product doesn't have more than required warranty
        res.mapped('product_tmpl_id')._check_provider_warranty_ids()
        return res

class ProductWarrantyOption(models.Model):
    _name = "product.warranty.option"
    _description = "Product Warranty Option"
    _auto = False
    _rec_name = "display_name"

    warranty_line_id = fields.Many2one("provider.warranty.line", string="Warranty Configuration", readonly=True)
    duration_id = fields.Many2one("warranty.duration", string="Duration", readonly=True)
    product_tmpl_id = fields.Many2one("product.template", string="Product", readonly=True)
    vendor_id = fields.Many2one("res.partner", string="Vendor", readonly=True)
    display_name = fields.Char(string="Display Name", readonly=True)

    def init(self):
        tools.drop_view_if_exists(self.env.cr, self._table)
        self.env.cr.execute("""
            CREATE OR REPLACE VIEW product_warranty_option AS (
                SELECT
                    row_number() OVER () as id,
                    rel.provider_warranty_line_id as warranty_line_id,
                    rel.warranty_duration_id as duration_id,
                    l.product_tmpl_id as product_tmpl_id,
                    l.vendor_id as vendor_id,
                    CONCAT(p.name, ' - ', d.name) as display_name
                FROM
                    provider_warranty_line_warranty_duration_rel rel
                JOIN
                    provider_warranty_line l ON l.id = rel.provider_warranty_line_id
                JOIN
                    warranty_duration d ON d.id = rel.warranty_duration_id
                JOIN
                    res_partner p ON p.id = l.vendor_id
            )
        """)



