from odoo import api, fields, models
from odoo.exceptions import ValidationError


class PurchaseOrderLine(models.Model):
    _inherit = "purchase.order.line"

    po_partner_id = fields.Many2one(
        'res.partner',
        related='order_id.partner_id',
        string="PO Vendor",
        store=False,
        readonly=True,
    )

    product_tmpl_id = fields.Many2one(related="product_id.product_tmpl_id", store=True)

    warranty_line_id = fields.Many2one(
        "provider.warranty.line",
        string="Warranty Provider",
        help="Select warranty provider configuration.",
        domain="[('id', 'in', available_warranty_ids)]"
    )

    warranty_duration_id = fields.Many2one(
        "warranty.duration",
        string="Warranty Duration",
        domain="[('id', 'in', available_duration_ids)]",
    )

    warranty_option_id = fields.Many2one(
        "product.warranty.option",
        string="Warranty",
        domain="[('product_tmpl_id', '=', product_tmpl_id)]",
        help="Select warranty (Provider - Duration).",
    )

    available_warranty_ids = fields.Many2many(
        'provider.warranty.line',
        compute='_compute_available_warranties',
        string='Available Warranties'
    )

    available_duration_ids = fields.Many2many(
        "warranty.duration",
        compute="_compute_available_durations",
        string="Available Durations",
    )

    warranty_months = fields.Integer(
        related='warranty_duration_id.months',
        string="Warranty (Months)",
        readonly=True
    )

    @api.depends('product_id')
    def _compute_available_warranties(self):
        """Compute available warranties based on product's seller_ids and PO partner."""
        for line in self:
            # if line.product_id:
            #     line.available_warranty_ids = self.env['provider.warranty.line'].search([
            #         ('product_tmpl_id', '=', line.product_tmpl_id.id)
            #     ])
            # else:
            line.available_warranty_ids = False

    @api.depends("warranty_line_id")
    def _compute_available_durations(self):
        for line in self:
            # if line.warranty_line_id:
            #     line.available_duration_ids = line.warranty_line_id.duration_ids
            # else:
            line.available_duration_ids = False

    # @api.onchange("warranty_option_id")
    # def _onchange_warranty_option_id(self):
    #     if self.warranty_option_id:
    #         self.warranty_line_id = self.warranty_option_id.warranty_line_id
    #         self.warranty_duration_id = self.warranty_option_id.duration_id
    #     else:
    #         self.warranty_line_id = False
    #         self.warranty_duration_id = False
    #
    # @api.onchange('product_id')
    # def onchange_product_auto_provider(self):
    #     """Auto-suggest warranty based on available warranties for the vendor."""
    #     # Clear warranty if product changes
    #     if not self.product_id or not self.order_id.partner_id:
    #         self.warranty_option_id = False
    #         self._onchange_warranty_option_id()
    #         return
    #
    #     # Get all options for this product
    #     all_options = self.env['product.warranty.option'].search([
    #         ('product_tmpl_id', '=', self.product_tmpl_id.id),
    #     ])
    #
    #     selected_option = False
    #
    #     if len(all_options) == 1:
    #         # If only one option exists globally for this product, select it
    #         selected_option = all_options[0]
    #     elif len(all_options) > 1 and self.order_id.partner_id:
    #         # If multiple options, try to filter by current PO vendor
    #         vendor_options = all_options.filtered(lambda o: o.vendor_id == self.order_id.partner_id)
    #         if len(vendor_options) == 1:
    #             selected_option = vendor_options[0]
    #
    #     if selected_option:
    #         self.warranty_option_id = selected_option
    #         self._onchange_warranty_option_id()
    #     elif self.warranty_option_id and self.warranty_option_id not in all_options:
    #         # Clear current warranty if it's no longer valid for the new product
    #         self.warranty_option_id = False
    #         self._onchange_warranty_option_id()
    #
    # def _prepare_stock_moves(self, picking):
    #     vals = super()._prepare_stock_moves(picking)
    #     for move_vals in vals:
    #         move_vals.update({
    #             'warranty_line_id': self.warranty_line_id.id if self.warranty_line_id else False,
    #             'warranty_duration_id': self.warranty_duration_id.id if self.warranty_duration_id else False,
    #             'warranty_option_id': self.warranty_option_id.id if self.warranty_option_id else False,
    #             'warranty_provider_name': self.warranty_line_id.vendor_id.name if self.warranty_line_id else False,
    #         })
    #     return vals


