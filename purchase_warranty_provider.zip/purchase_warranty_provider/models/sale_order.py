from odoo import api, fields, models

class SaleOrderLine(models.Model):
    _inherit = "sale.order.line"

    warranty_line_id = fields.Many2one(
        "provider.warranty.line",
        string="Warranty Provider",
        domain="[('id', 'in', available_warranty_ids)]",
        help="Select warranty provider configuration.",
    )

    warranty_seller_id = fields.Many2one(related="warranty_line_id.vendor_id", string="Warranty Seller")

    warranty_duration_id = fields.Many2one(
        "warranty.duration",
        string="Warranty Duration",
        domain="[('id', 'in', available_duration_ids)]",
    )

    warranty_option_id = fields.Many2one(
        "product.warranty.option",
        string="Warranty",
        domain="[('product_tmpl_id', '=', product_tmpl_id)]",
        help="Select warranty (Provider - Duration).",
    )

    product_tmpl_id = fields.Many2one(related="product_id.product_tmpl_id", string="Product Template")

    available_warranty_ids = fields.Many2many(
        "provider.warranty.line",
        compute="_compute_available_warranties",
        string="Available Warranties",
    )

    available_duration_ids = fields.Many2many(
        "warranty.duration",
        compute="_compute_available_durations",
        string="Available Durations",
    )

    is_warranty_readonly = fields.Boolean(
        compute="_compute_is_warranty_readonly",
        string="Is Warranty Readonly",
    )

    is_warranty_required = fields.Boolean(
        compute="_compute_is_warranty_readonly",
        string="Is Warranty Required",
    )

    def _get_sale_order_fields(self):
        res = super()._get_sale_order_fields()
        res.extend(["warranty_line_id", "warranty_seller_id", "warranty_duration_id"])
        return res

    @api.onchange("warranty_option_id")
    def _onchange_warranty_option_id(self):
        if self.warranty_option_id:
            self.warranty_line_id = self.warranty_option_id.warranty_line_id
            self.warranty_duration_id = self.warranty_option_id.duration_id
        else:
            self.warranty_line_id = False
            self.warranty_duration_id = False

    @api.onchange("product_id")
    def _onchange_product_id_auto_warranty(self):
        """Auto-select warranty if only one is available."""
        if self.product_id:
            options = self.env['product.warranty.option'].search([
                ('product_tmpl_id', '=', self.product_id.product_tmpl_id.id)
            ])
            if len(options) == 1 and not self.is_warranty_readonly:
                self.warranty_option_id = options[0]
                self._onchange_warranty_option_id()
            elif self.warranty_option_id and self.warranty_option_id not in options:
                self.warranty_option_id = False
                self._onchange_warranty_option_id()


    @api.depends("product_id")
    def _compute_available_warranties(self):
        """Compute available warranties from all sellers of the product."""
        for line in self:
            if line.product_id:
                line.available_warranty_ids = self.env['provider.warranty.line'].search([
                    ('product_tmpl_id', '=', line.product_id.product_tmpl_id.id)
                ])
            else:
                line.available_warranty_ids = False

    @api.depends("warranty_line_id")
    def _compute_available_durations(self):
        for line in self:
            if line.warranty_line_id:
                line.available_duration_ids = line.warranty_line_id.duration_ids
            else:
                line.available_duration_ids = False

    @api.depends('product_id.tracking')
    def _compute_is_warranty_readonly(self):
        for line in self:
            line.is_warranty_required = False
            if line.product_id and line.product_id.tracking == 'serial':
                line.is_warranty_readonly = True
            else:
                line.is_warranty_readonly = False
                # Commented since "provider_warranty_enable" field is removed
                # if line.product_id.product_tmpl_id.provider_warranty_enabled:
                #     line.is_warranty_required = True

    def _prepare_procurement_values(self, group_id=False):
        """Pass warranty info to stock moves."""
        res = super()._prepare_procurement_values(group_id=group_id)
        if self.warranty_line_id:
            res.update({
                "warranty_line_id": self.warranty_line_id.id,
                "warranty_duration_id": self.warranty_duration_id.id if self.warranty_duration_id else False,
                "warranty_option_id": self.warranty_option_id.id if self.warranty_option_id else False,
            })
        return res


