# -*- coding: utf-8 -*-

from odoo import fields, api, models

class StockLot(models.Model):
    _inherit = 'stock.lot'

    product_tmpl_id = fields.Many2one(
        related='product_id.product_tmpl_id',
        string="Product Template",
        store=True,
        readonly=True
    )

    warranty_option_id = fields.Many2one(
        "product.warranty.option",
        string="Warranty",
        domain="[('product_tmpl_id', '=', product_tmpl_id)]",
        help="Select warranty (Provider - Duration).",
    )

    @api.model
    def create(self, vals_list):
        res = super(StockLot, self).create(vals_list)
        if 'quant_ids' in vals_list and vals_list['quant_ids']:
            quant = self.env['stock.quant'].browse(vals_list['quant_ids'][0][2])
            if quant and quant.warranty_option_id:
                res.warranty_option_id = quant.warranty_option_id.id
        return res
