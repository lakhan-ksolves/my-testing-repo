from odoo import api, fields, models
from odoo.exceptions import ValidationError

class ProductTemplate(models.Model):
    _inherit = "product.template"
    
    provider_warranty_enabled = fields.Boolean(
        string="Warranty Provider",
        compute="_compute_has_warranty",
        help="If checked, you can configure warranty rules for this product.",
    )

    provider_warranty_ids = fields.One2many(
        "provider.warranty.line",
        "product_tmpl_id",
        string="Provider Warranties",
    )

    @api.constrains('provider_warranty_ids','tracking')
    def _check_provider_warranty_ids(self):
        """
        Make sure for no tracking product there is only
        one active warranty
        """
        for product in self:
            active_warranties = product.provider_warranty_ids.filtered(lambda w: w.active)
            if product.tracking == 'none' and len(active_warranties) > 1:
                raise ValidationError("There can only be one active warranty for this product.")

    def _compute_has_warranty(self):
        """
        If product has an active warranty then it has warranty enabled.
        """
        for product in self:
            if not len(product.provider_warranty_ids):
                product.provider_warranty_enabled = False
            else:
                product.provider_warranty_enabled = bool(product.provider_warranty_ids.filtered(lambda w: w.active))

    # Get available vendors for this product (from seller_ids)
    def _get_product_vendors(self):
        """Return list of vendor IDs associated with this product."""
        self.ensure_one()
        return self.seller_ids.mapped('partner_id').ids
    
class Product(models.Model):
    _inherit = 'product.product'

    @api.model
    def _get_fields_stock_barcode(self):
        return super()._get_fields_stock_barcode() + ['product_tmpl_id', 'provider_warranty_enabled']
