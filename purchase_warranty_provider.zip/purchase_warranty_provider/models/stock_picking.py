from odoo import models
from odoo.exceptions import ValidationError

class StockPicking(models.Model):
    _inherit = "stock.picking"

    # def button_validate(self):
    #     for picking in self:
    #         for move_line in picking.move_line_ids:
    #             if move_line.warranty_required and not move_line.warranty_option_id:
    #                 raise ValidationError(
    #                     f"Warranty is required for product '{move_line.product_id.display_name}' with tracking. "
    #                     f"Please select a warranty for the move line with Lot/Serial Number '{move_line.lot_id.name or ''}'."
    #                 )
    #     return super().button_validate()

    def _get_barcode_line_data(self):
        result = super()._get_barcode_line_data()
        # Add our custom fields
        for line_dict in result:
            mline = self.move_line_ids.filtered(lambda x: x.id == line_dict['id'])
            if mline:
                line_dict.update({
                    'warranty_line_id': mline.warranty_line_id.id if mline.warranty_line_id else False,
                    'warranty_provider_name': mline.warranty_line_id.vendor_id.name if mline.warranty_line_id else False,
                })
        return result
