/** @odoo-module **/

import BarcodePickingModel from '@stock_barcode/models/barcode_picking_model';
import { patch } from "@web/core/utils/patch";

patch(BarcodePickingModel.prototype, {
    get canBeValidate() {
        const result = super.canBeValidate;
        if (result) {
            for (const line of this.pageLines) {
                // Only require a warranty on lines that were actually received.
                // An ordered-but-not-received unit (qty_done = 0) is still a
                // pageLine; without this guard it has no warranty option and
                // would disable Validate from the start, blocking short receipts.
                if (line.qty_done > 0 && line.product_id.provider_warranty_enabled && !line.warranty_option_id) {
                    return false;
                }
            }
        }
        return result;
    },
});
