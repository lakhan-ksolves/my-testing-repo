/** @odoo-module */

import { Orderline } from "@point_of_sale/app/store/models";
import { patch } from "@web/core/utils/patch";

patch(Orderline.prototype, {
    setup(_defaultObj, options) {
        super.setup(...arguments);
        const line = options.sale_order_line_id || {};
        // Use arrays for multiple warranties
        this.warranty_line_ids = this.warranty_line_ids || line.warranty_line_ids || [];
        this.warranty_option_ids = this.warranty_option_ids || line.warranty_option_ids || [];
    },

    init_from_JSON(json) {
        super.init_from_JSON(...arguments);
        // Initialize as arrays
        this.warranty_line_ids = json.warranty_line_ids || [];
        this.warranty_option_ids = json.warranty_option_ids || [];
    },

    export_as_JSON() {
        const json = super.export_as_JSON(...arguments);
        // Send warranty arrays - backend _order_line_fields will convert to Many2many format
        json.warranty_line_ids = this.warranty_line_ids || [];
        json.warranty_option_ids = this.warranty_option_ids || [];
        return json;
    },

    getDisplayData() {
        return {
            ...super.getDisplayData(),
            warranty_line_ids: this.warranty_line_ids,
            warranty_option_ids: this.warranty_option_ids,
            warranty_details: this.get_warranty_details_string(),
        };
    },

    /**
     * Get warranty details as a formatted string for display
     * Prioritizes warranty_option_ids as they contain "Vendor - Duration"
     */
    get_warranty_details_string() {
        const details = [];

        // Use warranty_option_ids if available (contains Vendor - Duration)
        if (this.warranty_option_ids && this.warranty_option_ids.length > 0) {
            for (const option of this.warranty_option_ids) {
                const name = option.display_name || option[1] || '';
                if (name) {
                    details.push(name);
                }
            }
        }
        // Fallback to warranty_line_ids
        else if (this.warranty_line_ids && this.warranty_line_ids.length > 0) {
            for (const warranty of this.warranty_line_ids) {
                const name = warranty.display_name || warranty[1] || '';
                if (name) {
                    details.push(name);
                }
            }
        }

        return details.length > 0 ? details.join(", ") : "15 days Return";
    },

    /**
     * Get warranty details for POS receipt display
     */
    get_warranty_details() {
        const detailsString = this.get_warranty_details_string();
        if (detailsString !== "15 days Return") {
            return {
                name: detailsString,
                warranties: this.warranty_option_ids.length > 0 ? this.warranty_option_ids : this.warranty_line_ids,
            };
        }
        return false;
    },

    async setPackLotLines(packLotLinesData) {
        super.setPackLotLines(packLotLinesData);
        // After setting pack lot lines, fetch warranties from stock move lines
        await this._updateWarrantyFromLots();
    },

    async editPackLotLines() {
        await super.editPackLotLines();
        // After editing pack lot lines, fetch warranties from stock move lines
        await this._updateWarrantyFromLots();
    },

    async _updateWarrantyFromLots() {
        if (!this.pack_lot_lines || this.pack_lot_lines.length === 0) {
            return;
        }

        // Get lot names from pack_lot_lines
        const lotNames = this.pack_lot_lines
            .filter(line => line.lot_name)
            .map(line => line.lot_name);

        if (lotNames.length === 0) {
            return;
        }

        try {
            // Fetch all warranty lines and options from stock move lines based on lot names
            const result = await this.pos.env.services.orm.call(
                'stock.move.line',
                'search_read',
                [[
                    ['lot_id.name', 'in', lotNames],
                    ['warranty_line_id', '!=', false]
                ]],
                {
                    fields: ['warranty_line_id', 'warranty_option_id', 'lot_id'],
                }
            );

            if (result && result.length > 0) {
                // Collect all unique warranty_line_ids and warranty_option_ids
                const warrantyMap = new Map();
                const optionMap = new Map();

                for (const moveLineData of result) {
                    if (moveLineData.warranty_line_id) {
                        const warrantyId = moveLineData.warranty_line_id[0];
                        const warrantyName = moveLineData.warranty_line_id[1];
                        if (!warrantyMap.has(warrantyId)) {
                            warrantyMap.set(warrantyId, {
                                id: warrantyId,
                                display_name: warrantyName,
                            });
                        }
                    }
                    if (moveLineData.warranty_option_id) {
                        const optionId = moveLineData.warranty_option_id[0];
                        const optionName = moveLineData.warranty_option_id[1];
                        if (!optionMap.has(optionId)) {
                            optionMap.set(optionId, {
                                id: optionId,
                                display_name: optionName,
                            });
                        }
                    }
                }

                // Update local warranty info
                this.warranty_line_ids = Array.from(warrantyMap.values());
                this.warranty_option_ids = Array.from(optionMap.values());
            }
        } catch (error) {
            console.error('Error fetching warranties from lots:', error);
        }
    },
});
