/** @odoo-module **/

import LineComponent from '@stock_barcode/components/line';
import { patch } from "@web/core/utils/patch";
import { onWillStart } from "@odoo/owl";

patch(LineComponent.prototype, {

    setup() {
        super.setup();
        // Auto-load warranty options same as grouped logic
        onWillStart(() => {
            this.onSublineChangeProviderType(false, this.props.line);
        });
    },

    //----------------------------------------------------------------------
    // CHANGE PROVIDER TYPE (same pattern as grouped, but for single line)
    //----------------------------------------------------------------------
    async onSublineChangeProviderType(ev, line) {
        const currentOptionId = line.warranty_option_id || false;
        const productTmplId = line.product_tmpl_id;

        //-------------------------------------------
        // Load warranty options from product template
        //-------------------------------------------
        let options = [];

        if (productTmplId) {
            const domain = [
                ["product_tmpl_id", "=", productTmplId]
            ];
            options = await this.env.services.orm.call(
                "product.warranty.option",
                "search_read",
                [domain, ["id", "display_name", "warranty_line_id", "duration_id"]]
            );
        }

        //-------------------------------------------
        // Update memory
        //-------------------------------------------
        line.sub_warranty_options = options;
        this.env.model.trigger("update");
    },

    //----------------------------------------------------------------------
    // WARRANTY SELECT CHANGE (single line version)
    //----------------------------------------------------------------------
    async onLineChangeProviderWarranty(ev, line) {
        const optId = parseInt(ev.target.value || "0", 10) || false;
        const moveLineId = line.id;
        console.log("optId", optId);
        if (!optId) {
            await this.env.services.orm.call(
                "stock.move.line",
                "write",
                [[moveLineId], {
                    warranty_option_id: false,
                    warranty_line_id: false,
                    warranty_duration_id: false,
                }]
            );
            line.warranty_option_id = false;
            line.warranty_line_id = false;
            line.warranty_duration_id = false;
            return;
        }
        console.log("optId", optId);
        //-------------------------------------------
        // Read selected warranty
        //-------------------------------------------
        const res = await this.env.services.orm.call(
            "product.warranty.option",
            "read",
            [[optId], ["warranty_line_id", "duration_id"]]
        );
        const warrantyLineId = res?.[0]?.warranty_line_id?.[0] || false;
        const durationId = res?.[0]?.duration_id?.[0] || false;
        console.log("warrantyLineId", warrantyLineId);
        console.log("durationId", durationId);
        //-------------------------------------------
        // Write to backend
        //-------------------------------------------
        await this.env.services.orm.call(
            "stock.move.line",
            "write",
            [[moveLineId], {
                warranty_option_id: optId,
                warranty_line_id: warrantyLineId,
                warranty_duration_id: durationId,
            }],
            { context: { update_provider_type: true } }
        );
        console.log("::::::::warrantyLineId", warrantyLineId);
        console.log("::::::::durationId", durationId);
        //-------------------------------------------
        // Update UI memory
        //-------------------------------------------
        line.warranty_option_id = optId;
        line.warranty_line_id = warrantyLineId;
        line.warranty_duration_id = durationId;

        this.env.model.trigger("update");
    },


});
