/** @odoo-module **/

import GroupedLineComponent from "@stock_barcode/components/grouped_line";
import { patch } from "@web/core/utils/patch";
import { onWillStart } from "@odoo/owl";

patch(GroupedLineComponent.prototype, {
    setup() {
        super.setup();
        onWillStart(() => {
            this.onGroupedChangeProviderType(false, this.line);
        });
    },

    async onGroupedChangeProviderType(ev, line) {
        const currentOptionId = line.warranty_option_id ? (Array.isArray(line.warranty_option_id) ? line.warranty_option_id[0] : line.warranty_option_id) : false;
        const productTmplId = line.product_id.product_tmpl_id;
        //-------------------------------------------
        // Load warranty options from product template
        //-------------------------------------------
        let options = [];

        if (productTmplId) {
            const domain = [
                ["product_tmpl_id", "=", productTmplId]
            ];
            options = await this.env.services.orm.call(
                "product.warranty.option",
                "search_read",
                [domain, ["id", "display_name", "warranty_line_id", "duration_id"]]
            );
        }

        //-------------------------------------------
        // Update cached line values
        //-------------------------------------------
        line.group_warranty_options = options;
        this.env.model.trigger("update");
    },

    onGroupedChangeProviderWarranty: async function (ev, line) {
        const optId = parseInt(ev.target.value || "0", 10) || false;
        const ids = line.ids && line.ids.length ? line.ids : [line.id];

        if (!optId) {
            await this.env.services.orm.call(
                "stock.move.line",
                "write",
                [ids, {
                    warranty_option_id: false,
                    warranty_line_id: false,
                    warranty_duration_id: false,
                }]
            );

            line.warranty_option_id = false;
            line.warranty_line_id = false;
            line.warranty_duration_id = false;
            return;
        }

        // Read details from option
        const res = await this.env.services.orm.call(
            "product.warranty.option",
            "read",
            [[optId], ["warranty_line_id", "duration_id"]]
        );

        const warrantyLineId = res?.[0]?.warranty_line_id?.[0] || false;
        const durationId = res?.[0]?.duration_id?.[0] || false;

        // Update UI
        await this.env.services.orm.call(
            "stock.move.line",
            "write",
            [ids, {
                warranty_option_id: optId,
                warranty_line_id: warrantyLineId,
                warranty_duration_id: durationId,
            }]
        );
        window.location.reload();
    },

});
