{
    "name": "purchase_provider_warranty",
    "summary": "Purchase Provider Warranty",
    "description":"Purchase warranty provider customization",
    "version": "1.0",
    "author": "7Span",
    "website": "https://www.7span.com",
    "depends": ["purchase","stock","stock_barcode", "product", "sale", "pos_sale", "account"],
    "category": "Purchases",
    "license": "LGPL-3",
    "data": [
        "security/ir.model.access.csv",
        "views/warranty_view.xml",
        "views/product_view.xml",
        # "views/purchase_view.xml",
        "views/stock_move_views.xml",
        # "views/stock_quant_views.xml",
        # "views/sale_view.xml",
        "views/report_invoice.xml",
        "views/stock_lot_view.xml",
        "views/account_move_view.xml",
    ],

    "assets": {
        "web.assets_backend": [
            "purchase_warranty_provider/static/src/js/grouped_line_patch.js",
            "purchase_warranty_provider/static/src/js/line_patch.js",
            "purchase_warranty_provider/static/src/js/barcode_picking_model.js",
            "purchase_warranty_provider/static/src/xml/grouped_line_inherit.xml",
            "purchase_warranty_provider/static/src/xml/line_component_inherit.xml",
            "purchase_warranty_provider/static/src/scss/warranty_subline.scss",
        ],
        "point_of_sale._assets_pos": [
            "purchase_warranty_provider/static/src/js/pos_models.js",
            "purchase_warranty_provider/static/src/xml/pos_product_screen.xml",
        ]
    },
    "installable": True,
    "application": False,
}
